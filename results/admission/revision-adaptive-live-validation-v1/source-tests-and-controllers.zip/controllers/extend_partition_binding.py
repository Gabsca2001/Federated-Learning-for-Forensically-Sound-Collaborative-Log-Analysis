from pathlib import Path
import hashlib
import json
import shutil
repo=Path.cwd();out=Path(__file__).parent;lab=repo/'artifacts/revision-live-envelope-tpm-v1'
archive=lab/'failed-initialization-source/fl_forensics'
assert not archive.exists()
shutil.copytree(repo/'src/fl_forensics',archive,ignore=shutil.ignore_patterns('__pycache__'))
def edit(name, old, new):
    path=repo/'src/fl_forensics'/name;text=path.read_text();assert text.count(old)==1,(name,old)
    path.write_text(text.replace(old,new))
target=repo/'src/fl_forensics/partition_training_binding.py';assert not target.exists()
target.write_bytes((out/target.name).read_bytes())
edit('secure_round.py', '    initial_model_path: Path | None = None,\n', '    initial_model_path: Path | None = None,\n    partition_config_path: Path | None = None,\n')
edit('secure_round.py', '    if manifest.get("partition_config_sha256") != config_digest:\n        raise SecureRoundError("partition manifest was created from a different federation config")',
     '    from .partition_training_binding import partition_training_binding\n    partition_training = partition_training_binding(config, config_digest, manifest, partition_config_path)')
edit('secure_round.py', '    write_once(public / "federation.yaml", config_path.read_bytes())',
     '    write_once(public / "federation.yaml", config_path.read_bytes())\n    if partition_training is not None:\n        write_once(public / "partition-source-federation.yaml", partition_config_path.read_bytes())')
edit('secure_round.py','    if dba_training_config_path is not None:\n',
     '    if partition_training is not None:\n        training_contract["partition_training_binding"] = partition_training\n    if dba_training_config_path is not None:\n')
edit('in_round_admission.py', '                "live_envelope.py",', '                "live_envelope.py",\n                "partition_training_binding.py",')
edit('live_envelope.py', '    workspace = Path(workspace)\n', '    workspace = Path(workspace)\n    from .partition_training_binding import verify_public_partition_training_binding\n    verify_public_partition_training_binding(workspace / "public")\n')
print('EXPLICIT PARTITION/TRAINING BINDING INSTALLED')
