from pathlib import Path
repo=Path.cwd();out=Path(__file__).parent
for name in ('test_persistent_envelope_policy.py','test_live_envelope.py'):
    path=repo/'tests'/name
    assert not path.exists()
    path.write_bytes((out/name).read_bytes())
print('TESTS INSTALLED')
