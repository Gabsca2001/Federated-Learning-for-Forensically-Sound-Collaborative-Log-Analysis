from pathlib import Path
repo=Path.cwd();out=Path(__file__).parent
test=repo/'tests/test_live_envelope.py'
text=test.read_text()
old='    put(public / "partition-manifest.json", {"test": True})'
assert old in text
text=text.replace(old,'    public.mkdir(parents=True)\n    (public / "federation.yaml").write_text("test: true\\n")\n    put(public / "training-contract.json", {})\n    put(public / "partition-manifest.json", {"test": True, "partition_config_sha256": sha256_file(public / "federation.yaml")})')
test.write_text(text)
target=repo/'tests/test_partition_training_binding.py';assert not target.exists()
target.write_bytes((out/target.name).read_bytes())
template=(out/'live_runner_template.py').read_text().replace('revision-envelope-live-trust.yaml','revision-envelope-live-trust-v2.yaml')
template=template.replace("initial_model_path=root/'initial-model.json' if number==1 else None)","initial_model_path=root/'initial-model.json' if number==1 else None,\n            partition_config_path=Path('/app/configs/federation.yaml'))")
template=template.replace('revision-live-envelope:20261103-v1','revision-live-envelope:20261103-v2').replace('revision-live-envelope-tpm-v1','revision-live-envelope-tpm-v2')
(out/'live_runner_template_v2.py').write_text(template)
script=(out/'prepare_live_case.py').read_text()
script=script.replace('revision-live-envelope-tpm-v1','revision-live-envelope-tpm-v2').replace('revision-envelope-live-trust.yaml','revision-envelope-live-trust-v2.yaml')
script=script.replace('live-envelope-tpm-20261103-v1','live-envelope-tpm-20261103-v2')
script=script.replace('revision_live_envelope.py','revision_live_envelope_v2.py').replace('live_runner_template.py','live_runner_template_v2.py')
script=script.replace('revision-envelope-tpm-20261103-v1-', 'revision-envelope-tpm-20261103-v2-')
script=script.replace('reserved-live-protocol.json','reserved-live-protocol-v2.json').replace("repo/'Dockerfile.revision-live-envelope'","repo/'Dockerfile.revision-live-envelope-v2'")
script=script.replace('COPY Dockerfile.m4 /app/Dockerfile.m4\\nENV','COPY Dockerfile.m4 /app/Dockerfile.m4\\nCOPY Dockerfile.revision-dba /app/Dockerfile.revision-dba\\nENV')
(out/'prepare_live_case_v2.py').write_text(script)
print('V2 PREPARATION READY')
