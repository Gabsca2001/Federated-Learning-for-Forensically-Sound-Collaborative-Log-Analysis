"""Retain the failed pre-enrollment bootstrap and supply its measured input."""
from pathlib import Path
import json
repo=Path.cwd();lab=(repo/'artifacts/revision-live-envelope-tpm-v1').resolve()
assert lab.is_relative_to((repo/'artifacts').resolve())
assert not any((lab/'nodes').glob('*/enrollment-request.json'))
trust=(lab/'trust').resolve();archive=(lab/'bootstrap-attempt-001-trust-private').resolve()
assert trust.is_relative_to(lab) and archive.is_relative_to(lab) and not archive.exists()
assert not (trust/'manifest.json').exists()
trust.rename(archive)
dockerfile=repo/'Dockerfile.revision-live-envelope'
text=dockerfile.read_text();assert 'COPY Dockerfile.revision-dba' not in text
dockerfile.write_text(text+'COPY Dockerfile.revision-dba /app/Dockerfile.revision-dba\n')
(lab/'bootstrap-recovery-before-training.json').write_text(json.dumps({
    'incident':'First bootstrap failed before enrollment and before any local training because the image omitted the historical Dockerfile.revision-dba required by the retained measurement list.',
    'correction':'Copy that unchanged measured file into the new image; preserve the partial private trust workspace, rebuild the image and reinitialize in the same reserved experiment.',
    'policy_or_calibration_changed':False,'training_started':False,
    'private_partial_workspace':'bootstrap-attempt-001-trust-private'},sort_keys=True,indent=2)+'\n')
print('Pre-training bootstrap recovery recorded')
