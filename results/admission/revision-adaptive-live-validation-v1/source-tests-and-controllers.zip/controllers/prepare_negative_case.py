"""Reserve a fresh real-TPM negative mechanism test, before its training."""
from pathlib import Path
import json
import shutil
import numpy as np
from revision_dba_experiment import model_with_arrays
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.canonical import sha256_file
from fl_forensics.round_derivation import implementation_sha256

repo=Path.cwd();out=Path(__file__).parent
original=repo/'artifacts/revision-live-envelope-tpm-v2'
lab=repo/'artifacts/revision-live-envelope-unsupported-v1'
assert not lab.exists();lab.mkdir()
for folder in ('partition','config'):shutil.copytree(original/folder,lab/folder)
model=json.loads((original/'initial-model.json').read_bytes())
zero=model_with_arrays(model,[np.zeros_like(a) for a in arrays_from_export(model,np=np)])
(lab/'initial-model.json').write_bytes(derived_json_bytes(zero))
protocol=json.loads((original/'reserved-protocol-before-training.json').read_bytes())
protocol.update(profile='live-envelope-unsupported-context-negative-v1',branches=['clean'],rounds=1,
    initial_model_sha256=sha256_file(lab/'initial-model.json'),
    intervention='Zero every initial model tensor; preserve architecture, dataset and clean-only detector references. The already measured state distance is 7.125994791909875 versus the frozen support limit 2.460477352870833.',
    evaluation='Require 15 fresh valid Quotes, 15 real unmodified local trainings, 15 valid TPM bundle signatures and receipts; the head abstains with eligible proposed masses but the live adapter sets all final masses to zero and emits a fully verifiable failed round with no checkpoint.',
    primary_efficacy_comparison=False,implementation_sha256=implementation_sha256())
protocol.pop('runner_sha256',None)
text=(repo/'scripts/revision_live_envelope_v2.py').read_text()
assert "BRANCHES = ('clean','shadow','active')" in text
text=text.replace("BRANCHES = ('clean','shadow','active')","BRANCHES = ('clean',)").replace('ROUNDS = 5','ROUNDS = 1')
text=text.replace('root = Path(__file__).resolve().parents[1]','root = Path.cwd()')
text=text.replace('/app/scripts/revision_live_envelope_v2.py','/task/negative_runner.py')
text=text.replace('revision-live-envelope-tpm-v2','revision-live-envelope-unsupported-v1')
text=text.replace('revision-envelope-tpm-20261103-v2-', 'revision-envelope-negative-20261103-v1-')
text=text.replace("assert result['status']=='aggregated',result", "assert result['status']=='failed' and not result['checkpoint_created'],result")
text=text.replace('        for b in BRANCHES:\n            stage("campaign", b, ROUNDS)\n','')
text=text.replace('    def stage(which, branch="baseline", n=1):',f'    full += ["-v", "{out}:/task:ro"]\n\n    def stage(which, branch="baseline", n=1):')
(out/'negative_runner.py').write_text(text)
protocol['controller_sha256']=sha256_file(out/'negative_runner.py')
(lab/'reserved-protocol-before-training.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
(out/'negative-protocol.json').write_bytes((lab/'reserved-protocol-before-training.json').read_bytes())
print('NEGATIVE CONTEXT PROTOCOL FROZEN')
