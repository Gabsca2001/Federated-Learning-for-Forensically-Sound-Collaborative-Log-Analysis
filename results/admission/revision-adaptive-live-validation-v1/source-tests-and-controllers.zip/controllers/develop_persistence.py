"""Predeclared development comparison; no new reserved trajectories are used."""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np

repo = Path.cwd()
out = Path(__file__).parent
lab = repo / 'artifacts/revision-adaptive-live-policy-v1'
lab.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, v):
    data = (json.dumps(v, sort_keys=True, indent=2) + '\n').encode()
    if p.exists(): assert p.read_bytes() == data, p
    else: p.write_bytes(data)

from fl_forensics.round_derivation import implementation_sha256
before = {'implementation_sha256': implementation_sha256(),
          'files': {str(p.relative_to(repo)): sha(p) for p in sorted((repo/'src/fl_forensics').glob('*.py'))},
          'git_index_sha256': sha(repo/'.git/index'),
          'parent_completion_sha256': 'ca48267410724f4ddb20fbc0226e486f143b562527fde5411f416844f653cb91'}
if not (out/'before.json').exists():
    assert before['implementation_sha256'] == '3a5165d525b0d69079f6f5bf83ef939f46a269568907724913d3575010cf3073'
    save(out/'before.json', before)
    shutil.copytree(repo/'src/fl_forensics', lab/'before-source/fl_forensics', ignore=shutil.ignore_patterns('__pycache__'))
target = repo/'src/fl_forensics/persistent_envelope_policy.py'
if target.exists(): assert target.read_bytes() == (out/target.name).read_bytes()
else: target.write_bytes((out/target.name).read_bytes())

save(lab/'development-protocol-before-scoring.json', {
    'profile': 'bounded-persistence-development-v1', 'candidates': ['retreat', 'persistence-2', 'persistence-3', 'persistence-4'],
    'selection': 'Require zero never-attacker proposals, zero currently-clean scheduled-attacker proposals and zero quorum loss in 48 already-used development cases; among bounded candidates choose largest shadow TP, ties smaller confirmation count. If none eligible retain retreat and explicitly reject the new rule.',
    'calibration': 'Unchanged clean-only model, global risk and client envelope calibration. Attack truth is used only to evaluate these development candidates, never as a detector input.',
    'new_reserved_cases_generated': False})

from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
from fl_forensics.persistent_envelope_policy import PersistentEnvelopePolicy
names = ['retreat', 'persistence-2', 'persistence-3', 'persistence-4']
rows = []
geometry = repo/'artifacts/revision-geometry-detector-v1'
for source in ('revision-sequential-round-policy-v1', 'revision-current-evidence-policy-v1'):
    root = repo/'artifacts'/source
    for task in json.loads((root/'reserved-execution-before-training.json').read_bytes())['tasks']:
        cohort = task['cohort']
        cal = json.loads((geometry/'policy-calibration'/f'{cohort}.json').read_bytes())
        env = json.loads((geometry/'policy-calibration'/f'{cohort}-envelope.json').read_bytes())
        policies = {'retreat': ClientEnvelopePolicy(cal, env)}
        policies.update({f'persistence-{n}': PersistentEnvelopePolicy(cal, env, confirmation_rounds=n) for n in (2,3,4)})
        counts = {n: dict(tp=0, never=0, clean_scheduled=0, quorum=0) for n in names}
        for number in range(1, 16):
            response = json.loads((root/'private-episodes'/task['stream']/'rounds'/f'round-{number:03d}'/'worker-response.json').read_bytes())
            scored = response['scored']
            supported = all(scored['state_distances'][v][0] <= min(cal['state_support_limits'][v], env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in ('conditioned','state-disabled'))
            for name, policy in policies.items():
                result = policy.step(number, {v: scored['risk'][v][0] for v in ('conditioned','state-disabled')},
                    context_supported=supported, mandatory_gate=dict.fromkeys(cal['clients'], True),
                    masses=dict.fromkeys(cal['clients'], 1), expected_previous_digest=policy.head,
                    source_observation_sha256=hashlib.sha256(f'{source}:{task["stream"]}:{number}'.encode()).hexdigest())
                chosen = set(result['quarantine_current_round'])
                intended = set(task['attackers']) if task['mode']=='distributed' else set()
                active = intended if number in task['attack_rounds'] else set()
                counts[name]['tp'] += len(chosen & active)
                counts[name]['never'] += len(chosen-intended)
                counts[name]['clean_scheduled'] += len((chosen & intended)-active)
                counts[name]['quorum'] += int(not result['proposal_quorum_satisfied'])
        rows.append({'source':source, 'task':task, 'methods':counts})
totals = {n: {k: sum(r['methods'][n][k] for r in rows) for k in ('tp','never','clean_scheduled','quorum')} for n in names}
for n in names: totals[n]['shadow_tp'] = sum(r['methods'][n]['tp'] for r in rows if r['task']['branch']=='shadow-FedAvg')
eligible = [n for n in names[1:] if not any(totals[n][k] for k in ('never','clean_scheduled','quorum'))]
selected = max(eligible,key=lambda n:(totals[n]['shadow_tp'], -names.index(n))) if eligible else 'retreat'
result = {'totals':totals,'selected':selected,'eligible':eligible,'cases':rows}
save(lab/'development-results.json',result)
save(out/'development-results.json',result)
print(json.dumps({'totals':totals,'selected':selected,'eligible':eligible}),flush=True)
