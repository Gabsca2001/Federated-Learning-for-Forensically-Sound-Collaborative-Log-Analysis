"""Negative verification over disposable copies of fresh signed TPM evidence."""
from pathlib import Path
import json
import shutil
import torch
torch.set_num_threads(1)
from fl_forensics.in_round_admission import verify_in_round_secure_round
from fl_forensics.storage import load_json
from fl_forensics.preprocessing import derived_json_bytes
from revision_dba_experiment import save

source=Path('/reference');audit=Path('/audit');base=audit/'baseline'
assert not base.exists()
def ignore(folder,names):return [n for n in names if n=='observable-assets' or n.endswith('.private.pem')]
shutil.copytree(source/'branches/active',base/'branches/active',ignore=ignore)
for number in range(1,6):
    rel=Path('branches/active/rounds')/f'round-{number:03d}'/'public/observable-assets'
    (base/rel).symlink_to(source/rel,target_is_directory=True)

def verify(root):
    workspace=root/'branches/active/rounds/round-005'
    return verify_in_round_secure_round(workspace=workspace,trust_workspace=source/'trust',
        submissions_root=workspace/'submissions',validation_split_path=source/'partition/server/splits/validation.json',
        client_receipts=workspace/'client-receipts',require_derivation=True)
def change(path,mutate):
    value=load_json(path);mutate(value);path.chmod(0o644);path.write_bytes(derived_json_bytes(value))
baseline=verify(base);assert baseline['status']=='verified',baseline
save(audit/'baseline-verification.json',baseline)
cases=[]
specs=[
    ('current-observable-result','round-005/observable-policy-result.json',lambda v:v.update(attack_labels_used=True)),
    ('predecessor-observable-history','round-004/observable-policy-result.json',lambda v:v['history'][0].update(context_supported=False)),
    ('client-bundle-signature','round-005/submissions/client01/bundle.json',lambda v:v['signature'].update(value_b64='A'+v['signature']['value_b64'][1:] if not v['signature']['value_b64'].startswith('A') else 'B'+v['signature']['value_b64'][1:])),
    ('signed-final-mass','round-005/in-round-decisions/client01.json',lambda v:v['core'].update(effective_weight_decimal='999999')),
    ('predecessor-checkpoint','round-004/checkpoint/manifest.json',lambda v:v['core'].update(global_model_sha256='0'*64)),
]
for name,relative,mutation in specs:
    target=audit/name;shutil.copytree(base,target,symlinks=True)
    changed=target/'branches/active/rounds'/relative
    change(changed,mutation)
    result=verify(target)
    assert result['status']!='verified',(name,result)
    save(audit/f'{name}-verification.json',result)
    cases.append({'mutation':name,'status':result['status'],'errors':result.get('errors',[])})
    print(json.dumps({'negative_case':name,'rejected':True}),flush=True)
save(audit/'summary.json',{'unmodified_copy_verified':True,'original_inputs_modified':False,'cases':cases})
