"""Freeze a fresh, bounded, swtpm integration case before any local training."""
from pathlib import Path
import hashlib
import json
import shutil
import yaml

repo=Path.cwd();out=Path(__file__).parent
lab=repo/'artifacts/revision-live-envelope-tpm-v1'
lab.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    p.parent.mkdir(exist_ok=True,parents=True)
    data=(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
    if p.exists():assert p.read_bytes()==data
    else:p.write_bytes(data)

# Correct a test expectation: the retained retreat channel can act earlier than
# the bounded channel; it must not be disabled by this additional experiment.
test=repo/'tests/test_persistent_envelope_policy.py'
text=test.read_text()
old='    assert not step(p, 7, 2.1)["quarantine_current_round"]'
if old in text:
    text=text.replace(old,'    assert not step(p, 7, 2.1)["clients"]["a"]["bounded_persistence_proposal"]')
    test.write_text(text)

source=repo/'artifacts/m3-data24-parquet-non-iid'
if not (lab/'partition').exists():shutil.copytree(source,lab/'partition')
assert sha(lab/'partition/manifest.json')=='87ef8d0d9aa21ed529f02a171219a10ee508cb39985b9402aff54ce77ce167b9'
assets=lab/'config/observable-assets';assets.mkdir(exist_ok=True,parents=True)
models=repo/'artifacts/revision-state-conditioned-heldout-v1/models/non-iid'
envelopes=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
for name,original in {'conditioned.npz':models/'conditioned.npz','state-disabled.npz':models/'state-disabled.npz',
                      'calibration.json':envelopes/'non-iid.json','envelope.json':envelopes/'non-iid-envelope.json'}.items():
    target=assets/name
    if not target.exists():shutil.copyfile(original,target)
    assert sha(target)==sha(original)

federation=yaml.safe_load((repo/'configs/revision-dba-live-federation.yaml').read_text())
federation['training']['seed']=541593
config=lab/'config/federation.yaml'
if not config.exists():config.write_text(yaml.safe_dump(federation,sort_keys=False))
initial=repo/'artifacts/m5-secure-multiround-local-test-v1/rounds/round-011/checkpoint/global-model.json'
assert sha(initial)=='39075d9cbf7c45248c475ae3ddfb66f0e032d55cc210eba2a9e97c19e3d594e5'
if not (lab/'initial-model.json').exists():shutil.copyfile(initial,lab/'initial-model.json')
plan=json.loads((repo/'configs/revision-dba-live-plan.json').read_bytes())
plan['plan']['seed']=541593
plan['plan']['client_components']={'client02':[13],'client07':[17],'client13':[24]}
save(lab/'config/dba-plan.json',plan)
for mode in ('enforce','audit_only'):
    config=yaml.safe_load((repo/'configs/in-round-admission.yaml').read_text())
    config['runtime_admission']['policy_id']='live-envelope-'+mode+'-v1'
    config['runtime_admission']['primary_policy']='observable_envelope'
    config['runtime_admission']['observable_policy']={'profile':'live-client-envelope-retreat-v1','mode':mode,
        'assets':{p.name:sha(p) for p in assets.iterdir()}}
    path=lab/'config'/f'{mode}.yaml'
    if not path.exists():path.write_text(yaml.safe_dump(config,sort_keys=False))

trust=yaml.safe_load((repo/'configs/revision-dba-live-trust.yaml').read_text())
trust['attestation']['baseline_id']='live-envelope-tpm-20261103-v1'
trust['attestation']['challenge_lifetime_seconds']=600
trust['attestation']['result_lifetime_seconds']=1800
for component,path in [('observable-adapter','src/fl_forensics/live_envelope.py'),
                       ('observable-head','src/fl_forensics/client_envelope_policy.py'),
                       ('observable-predictor','src/fl_forensics/state_conditioned_audit.py')]:
    trust['measurements'].append({'component_id':component,'component_version':'1.0.0','pcr_index':7,'path':path})
trustpath=repo/'configs/revision-envelope-live-trust.yaml'
if not trustpath.exists():trustpath.write_text(yaml.safe_dump(trust,sort_keys=False))

# Reuse only the host plumbing of the earlier isolated client/TPM runner.
legacy=(repo/'scripts/revision_attested_dba.py').read_text()
host=legacy[legacy.index('def host(args):'):legacy.index('\ndef main():')]
host=host.replace('/app/scripts/revision_attested_dba.py','/app/scripts/revision_live_envelope.py')
host=host.replace('revision-dba-20261103-v1-', 'revision-envelope-tpm-20261103-v1-')
start=host.index('        stage("compare")')
end=host.index('        image_meta =',start)
host=host[:start]+host[end:]
host=host.replace('print("LIVE CHAIN COMPLETED", flush=True)','print("LIVE ENVELOPE TPM CASE COMPLETED", flush=True)')
template=(out/'live_runner_template.py').read_text()
runner=repo/'scripts/revision_live_envelope.py'
content=template.replace('# INSERT_HOST',host)
if runner.exists():assert runner.read_text()==content
else:runner.write_text(content)

from fl_forensics.round_derivation import implementation_sha256
protocol={'profile':'bounded-live-envelope-tpm-v1','branches':['clean','shadow','active'], 'rounds':5,
          'horizon_rationale':'Three DBA rounds and two clean continuations, sufficient to exercise temporal confirmation, exclusion, release and authenticated predecessor replay; mechanism case rather than a robustness benchmark.',
          'partition_sha256':sha(lab/'partition/manifest.json'),'initial_model_sha256':sha(initial),
          'training_seed':541593,'attack_plan':plan,'calibration':'unchanged clean-only frozen non-IID assets',
          'development_outcome':'All bounded-persistence variants failed the predeclared no-false-currently-clean proposal criterion and are NOT deployed.',
          'selected_head':'client-envelope-retreat-policy-v1; persistent-peak limitation retained',
          'branches_semantics':{'clean':'unmodified training, enforced policy', 'shadow':'declared DBA, trust enforced, statistical proposals recorded only', 'active':'declared DBA, trust and statistical proposals enforced'},
          'evaluation':'validation only; every fixed round, full trigger plus three components and clean macro-F1; no test access, no selected endpoints',
          'emulated_TPM':True,'implementation_sha256':implementation_sha256(),
          'source_files':{str(p.relative_to(repo)):sha(p) for p in sorted((repo/'src/fl_forensics').glob('*.py'))},
          'inputs':{str(p.relative_to(lab)):sha(p) for p in (lab/'config').rglob('*') if p.is_file()},
          'runner_sha256':sha(runner),'trust_config_sha256':sha(trustpath),
          'parent_completion_sha256':'ca48267410724f4ddb20fbc0226e486f143b562527fde5411f416844f653cb91'}
save(lab/'reserved-protocol-before-training.json',protocol)
save(out/'reserved-live-protocol.json',protocol)
dockerfile=repo/'Dockerfile.revision-live-envelope'
dockerfile.write_text('FROM revision-attested-chain:20261102-v4\nCOPY src /app/src\nCOPY configs /app/configs\nCOPY scripts /app/scripts\nCOPY Dockerfile.m4 /app/Dockerfile.m4\nENV PYTHONPATH=/app/src:/app/scripts\nENV OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MKL_CBWR=COMPATIBLE\n')
print(json.dumps({'lab':str(lab),'implementation_sha256':protocol['implementation_sha256'],'protocol_sha256':sha(lab/'reserved-protocol-before-training.json')}),flush=True)
