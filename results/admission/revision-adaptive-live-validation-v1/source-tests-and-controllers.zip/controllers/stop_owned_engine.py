"""Stop only the idle engine started for this validation task."""
from pathlib import Path
import json
import os
import signal
import subprocess
repo=Path('/home/gio/projects/Federated-Learning-for-Forensically-Sound-Collaborative-Log-Analysis')
state=(repo/'artifacts/revision-dba-isolated-runtime-v1').resolve()
assert state.is_relative_to((repo/'artifacts').resolve())
pid=int((state/'engine.pid').read_text())
assert pid==40666, 'Different process: inspect rather than stopping it'
cmd=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
assert b'/usr/bin/dockerd' in cmd and b'unix:///run/revision-dba-engine.sock' in cmd
assert str(state/'data').encode() in cmd
env={**os.environ,'DOCKER_HOST':'unix:///run/revision-dba-engine.sock','DOCKER_CONFIG':'/tmp/revision-dba-docker-config'}
running=subprocess.check_output(['docker','ps','-q'],env=env,text=True).strip()
assert not running,'A container is still active; do not stop its service'
os.kill(pid,signal.SIGTERM)
out=Path(__file__).parent
(out/'runtime-cleanup.json').write_text(json.dumps({'task_owned_engine_pid':pid,'signal':'SIGTERM',
    'all_experiment_containers_stopped_before_signal':True,'other_Docker_engines_touched':False,
    'TPM_states_and_images_preserved':True},sort_keys=True,indent=2)+'\n')
print('Stopped only the verified idle task engine',pid)
