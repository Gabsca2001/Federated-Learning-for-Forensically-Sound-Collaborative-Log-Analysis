"""Explain retained negative results without converting labels into detector input."""
from pathlib import Path
import hashlib
import json
import numpy as np
from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
from fl_forensics.persistent_envelope_policy import PersistentEnvelopePolicy

repo=Path.cwd();out=Path(__file__).parent
test=repo/'tests/test_live_envelope.py'
text=test.read_text()
old='put(fixture.public / "partition-manifest.json", {"different": True})'
assert old in text
test.write_text(text.replace(old,'put(fixture.public / "partition-manifest.json", {"different": True, "partition_config_sha256": sha256_file(fixture.public / "federation.yaml")})'))
data=json.loads((out/'development-results.json').read_bytes())
case=next(r for r in data['cases'] if r['methods']['persistence-3']['clean_scheduled'])
root=repo/'artifacts'/case['source'];task=case['task'];cohort=task['cohort']
calroot=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
cal=json.loads((calroot/f'{cohort}.json').read_bytes());env=json.loads((calroot/f'{cohort}-envelope.json').read_bytes())
policies={'retreat':ClientEnvelopePolicy(cal,env),'persistence-3':PersistentEnvelopePolicy(cal,env)}
rows=[]
for number in range(1,16):
    result=json.loads((root/'private-episodes'/task['stream']/'rounds'/f'round-{number:03d}'/'worker-response.json').read_bytes())['scored']
    risks={v:result['risk'][v][0] for v in ('conditioned','state-disabled')}
    support=all(result['state_distances'][v][0]<=min(cal['state_support_limits'][v],env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in risks)
    decisions={name:p.step(number,risks,context_supported=support,mandatory_gate=dict.fromkeys(cal['clients'],True),
        masses=dict.fromkeys(cal['clients'],1),expected_previous_digest=p.head,
        source_observation_sha256=hashlib.sha256(f'{case["source"]}:{task["stream"]}:{number}'.encode()).hexdigest()) for name,p in policies.items()}
    active=set(task['attackers']) if number in task['attack_rounds'] else set()
    for c in set(decisions['persistence-3']['quarantine_current_round'])-active:
        i=cal['clients'].index(c)
        rows.append({'round':number,'client':c,'current_training_poisoned':False,
                     'risk':[risks[v][i] for v in ('conditioned','state-disabled')],
                     'client_limits':env['tensor_risk_limits'][i],
                     'retreat_record':decisions['retreat']['clients'][c],
                     'persistence_record':decisions['persistence-3']['clients'][c],
                     'qualification':'The current update is unmodified but starts from the attacked shared state. This is an intervention error relative to currently poisoned updates, not proof that the update has no inherited numerical effect.'})
diagnosis={'profile':'development-negative-result-diagnosis-v1','case':case['task'],'events':rows,
           'interpretation':'Persistent current residual excess can also describe a clean local optimization response to an already contaminated shared model. A finite confirmation bound eliminates peak suppression, but cannot itself identify current poisoning or coordinated intent.',
           'promotion':'Rejected by the predeclared criterion; old retreat head remains the live integration candidate.'}
(out/'development-negative-diagnosis.json').write_text(json.dumps(diagnosis,sort_keys=True,indent=2)+'\n')
print(json.dumps({'events':[{'round':r['round'],'client':r['client'],'risk':r['risk'],'limits':r['client_limits']} for r in rows]}))
