"""New swtpm-backed, authenticated observable-policy integration case."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import revision_attested_dba as legacy

CLIENTS = legacy.CLIENTS
BRANCHES = ('clean','shadow','active')
ROUNDS = 5
TRUST_CONFIG = Path('/app/configs/revision-envelope-live-trust.yaml')
TCTI = legacy.TCTI
sha, save = legacy.sha, legacy.save
def omitted(*args):return False


def internal(stage,branch,number):
    legacy.BRANCHES=BRANCHES;legacy.ROUNDS=ROUNDS;legacy.TRUST_CONFIG=TRUST_CONFIG
    legacy.CONFIG=Path('/evidence/config/federation.yaml')
    root=Path('/evidence');campaign=root/'branches'/branch
    workspace=campaign/'rounds'/f'round-{number:03d}'
    if stage=='bootstrap':
        from fl_forensics.trust import initialize_trust_workspace
        from fl_forensics.secure_round import _coordinator_signer
        from fl_forensics.round_derivation import implementation_sha256
        protocol=json.loads((root/'reserved-protocol-before-training.json').read_bytes())
        assert protocol['implementation_sha256']==implementation_sha256()
        initialize_trust_workspace(workspace=root/'trust',project_root=Path('/app'),
            trust_config_path=TRUST_CONFIG,clients_config_path=Path('/app/configs/clients.yaml'))
        _coordinator_signer(root/'coordinator',create=True)
        for name in BRANCHES:shutil.copytree(root/'coordinator/authority',root/'branches'/name/'authority')
        save(root/'protocol.json',{'reserved_protocol_sha256':sha(root/'reserved-protocol-before-training.json'),
            'emulated_TPM':True,'source_implementation_sha256':implementation_sha256()})
        return {'status':'initialized'}
    if stage=='init':
        from fl_forensics.secure_round import initialize_secure_round
        return initialize_secure_round(workspace=workspace,trust_workspace=root/'trust',
            partition_manifest_path=root/'partition/manifest.json',config_path=root/'config/federation.yaml',
            secure_config_path=Path('/app/configs/secure-round.yaml'),coordinator_workspace=campaign,
            campaign_id='live-envelope-'+branch+'-20261103-v1',round_number=number,
            previous_round_workspace=campaign/'rounds'/f'round-{number-1:03d}' if number>1 else None,
            in_round_admission_config_path=root/'config'/('audit_only.yaml' if branch=='shadow' else 'enforce.yaml'),
            dba_training_config_path=root/'config/dba-plan.json' if branch!='clean' else None,
            initial_model_path=root/'initial-model.json' if number==1 else None)
    if stage=='aggregate':
        from fl_forensics.submission_evidence_workspace import create_submission_inventory_workspace
        from fl_forensics.in_round_admission import admit_and_aggregate_in_round
        receipts=root/'client-copies'/branch/f'round-{number:03d}';inventory=root/'inventories'/branch/f'round-{number:03d}.json'
        intake=create_submission_inventory_workspace(workspace=workspace,trust_workspace=root/'trust',client_receipts=receipts,
            submissions_root=workspace/'submissions',inventory_path=inventory,coordinator_workspace=campaign)
        save(root/'reports'/f'{branch}-{number:03d}-intake.json',intake)
        result=admit_and_aggregate_in_round(workspace=workspace,trust_workspace=root/'trust',submissions_root=workspace/'submissions',
            validation_split_path=root/'partition/server/splits/validation.json',coordinator_workspace=campaign,
            client_receipts=receipts,input_inventory_path=inventory)
        save(root/'reports'/f'{branch}-{number:03d}-admission.json',result)
        assert result['status']=='aggregated',result
        return result
    return legacy.internal(stage,branch,number)

# INSERT_HOST

def main():
    p=argparse.ArgumentParser();p.add_argument('--stage');p.add_argument('--branch',default='clean');p.add_argument('--round',type=int,default=1)
    p.add_argument('--image',default='revision-live-envelope:20261103-v1');p.add_argument('--workspace',default='artifacts/revision-live-envelope-tpm-v1')
    args=p.parse_args()
    if args.stage: print(json.dumps(internal(args.stage,args.branch,args.round),indent=2),flush=True)
    else:host(args)

if __name__=='__main__':main()
