"""Guarded implementation of the new, separately named live policy profile."""
from pathlib import Path
import hashlib
import json
import shutil

repo=Path.cwd(); out=Path(__file__).parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((out/'before.json').read_bytes())['files']
def edit(name, replacements):
    path=repo/name
    if (out/'before-live'/Path(name).name).exists():
        raise ValueError('installer is intentionally one-shot; inspect partial deployment')
    assert sha(path)==before[name], name
    (out/'before-live').mkdir(exist_ok=True)
    shutil.copyfile(path,out/'before-live'/path.name)
    text=path.read_text()
    for old,new,count in replacements:
        assert text.count(old)==count, (name, old[:90],text.count(old),count)
        text=text.replace(old,new)
    path.write_text(text)

target=repo/'src/fl_forensics/live_envelope.py'
assert not target.exists()
target.write_bytes((out/target.name).read_bytes())
edit('src/fl_forensics/composite_admission_models.py', [('    "gated_composite",\n', '    "gated_composite",\n    "observable_envelope",\n', 1)])
edit('src/fl_forensics/in_round_admission_models.py', [
    ('Literal["gated_composite", "sequential"]','Literal["gated_composite", "sequential", "tpm_only", "observable_envelope"]',1),
    ('Literal["FedAvg-gated-composite", "FedAvg-sequential"]','Literal["FedAvg-gated-composite", "FedAvg-sequential", "FedAvg-tpm-only", "FedAvg-observable-envelope"]',1)])
edit('src/fl_forensics/in_round_admission.py', [
    ('                "byzantine.py",','                "client_envelope_policy.py",\n                "current_evidence_policy.py",\n                "sequential_decision.py",\n                "state_conditioned_audit.py",\n                "live_envelope.py",\n                "byzantine.py",',1),
    ('    contract = build_in_round_contract(\n', '    if load_yaml(config_path)[0].get("runtime_admission", {}).get("primary_policy") == "observable_envelope":\n        from .live_envelope import install_assets\n        install_assets(public_workspace, config_path)\n    contract = build_in_round_contract(\n',1),
    ('if decision.policy == contract.core.primary_policy','if decision.policy == ("tpm_only" if contract.core.primary_policy == "observable_envelope" else contract.core.primary_policy)',1),
    ('    decisions = _load_or_create_runtime_decisions(\n        workspace=workspace,\n        records=records,\n        statistical_state=statistical_state,',
     '    if contract.core.primary_policy == "observable_envelope":\n        from .live_envelope import apply_live_envelope\n        statistical_state = apply_live_envelope(workspace=workspace, trust_workspace=trust_workspace, validation_split_path=validation_split_path, context=context, contract=contract, records=records, base=base, statistical_state=statistical_state, create=True)\n    decisions = _load_or_create_runtime_decisions(\n        workspace=workspace,\n        records=records,\n        statistical_state=statistical_state,',1),
    ('        decisions = _load_or_create_runtime_decisions(\n            workspace=workspace,\n            records=records,\n            statistical_state=statistical_state,',
     '        if contract.core.primary_policy == "observable_envelope":\n            from .live_envelope import apply_live_envelope\n            statistical_state = apply_live_envelope(workspace=workspace, trust_workspace=trust_workspace, validation_split_path=validation_split_path, context=context, contract=contract, records=records, base=base, statistical_state=statistical_state, create=False)\n        decisions = _load_or_create_runtime_decisions(\n            workspace=workspace,\n            records=records,\n            statistical_state=statistical_state,',1)])
edit('src/fl_forensics/round_derivation.py', [
    ('    decisions = _load_or_create_runtime_decisions(\n        workspace=workspace,\n        records=records,\n        statistical_state=statistical,',
     '    if contract.core.primary_policy == "observable_envelope":\n        from .live_envelope import apply_live_envelope\n        statistical = apply_live_envelope(workspace=workspace, trust_workspace=trust_workspace, validation_split_path=validation_split_path, context=context, contract=contract, records=records, base=base, statistical_state=statistical, create=False)\n    decisions = _load_or_create_runtime_decisions(\n        workspace=workspace,\n        records=records,\n        statistical_state=statistical,',1)])
edit('src/fl_forensics/counterfactual_round.py', [
    ('        if mode == "rescore_round":\n', '        if mode == "rescore_round":\n            if contract.core.primary_policy == "observable_envelope":\n                raise CounterfactualError("observable envelope rescoring requires a newly supported cohort and authenticated prefix; frozen-decisions mode remains available")\n',1)])
edit('src/fl_forensics/secure_round.py', [
    ('    dba_training_config_path: Path | None = None,\n', '    dba_training_config_path: Path | None = None,\n    initial_model_path: Path | None = None,\n',1),
    ('    if round_number < 1:\n', '    if initial_model_path is not None and round_number != 1:\n        raise SecureRoundError("an external initial model is permitted only at genesis")\n    if round_number < 1:\n',1),
    ('        base_bytes = derived_json_bytes(base_export)\n        previous_checkpoint_sha256 = GENESIS_DIGEST',
     '        if initial_model_path is not None:\n            np = dependencies()[0]\n            initial = load_json(initial_model_path)\n            if initial.get("architecture") != base_export.get("architecture") or initial.get("class_names") != base_export.get("class_names") or tensor_schema(initial) != tensor_schema(base_export):\n                raise SecureRoundError("initial model architecture or tensor schema mismatch")\n            if not all(np.isfinite(a).all() for a in arrays_from_export(initial, np=np)):\n                raise SecureRoundError("initial model has nonfinite tensors")\n            base_export = initial\n        base_bytes = derived_json_bytes(base_export)\n        previous_checkpoint_sha256 = GENESIS_DIGEST',1)])
print('LIVE PROFILE INSTALLED',flush=True)
