"""Evaluate every predeclared live endpoint in the frozen numerical image."""
from pathlib import Path
import json
from datetime import datetime
import torch
torch.set_num_threads(1)
from revision_dba_experiment import outcomes,predict,save
from fl_forensics.canonical import sha256_file
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan
from fl_forensics.federated_model import dependencies
from fl_forensics.storage import load_json

root=Path('/evidence');deps=dependencies()
protocol=load_json(root/'reserved-protocol-before-training.json')
plan=DistributedBackdoorPlan.model_validate(protocol['attack_plan']['plan'])
rows=load_json(root/'partition/server/splits/validation.json')['rows']['validation']
initial=load_json(root/'initial-model.json')
pred,_=predict(initial,rows,deps);correct=[p==r['label'] for p,r in zip(pred,rows,strict=True)]
allrows=[]
for branch in protocol['branches']:
    for number in range(1,6):
        workspace=root/'branches'/branch/'rounds'/f'round-{number:03d}'
        model=load_json(workspace/'checkpoint/global-model.json')
        checkpoint=load_json(workspace/'checkpoint/manifest.json')['core']
        context=load_json(workspace/'public/round-context.json')['core']
        audit=load_json(workspace/'observable-policy-result.json')
        decisions={p.stem:load_json(p)['core'] for p in (workspace/'in-round-decisions').glob('*.json')}
        excluded=[c for c,d in decisions.items() if float(d['effective_weight_decimal'])==0]
        active=set(plan.client_components) if branch!='clean' and number in plan.attack_rounds else set()
        numerically_nonzero=[c for c,d in decisions.items() if float(d['effective_weight_decimal'])>0]
        metrics=outcomes(model,rows,plan,correct,deps)
        allrows.append({'branch':branch,'round':number,'checkpoint_sha256':sha256_file(workspace/'checkpoint/manifest.json'),
            'global_model_sha256':sha256_file(workspace/'checkpoint/global-model.json'),
            'observable_result_sha256':sha256_file(workspace/'observable-policy-result.json'),
            'support':audit['decision']['supported'],'proposed_quarantines':audit['decision']['quarantine_current_round'],
            'actual_exclusions':sorted(excluded),'current_poisoned_updates_intercepted':len(set(excluded)&active),
            'benign_current_updates_excluded':len(set(excluded)-active),
            'poisoned_current_updates':len(active),'actual_contributors':len(numerically_nonzero),
            'quotes_and_local_trainings':15,'all_bundle_signatures_emulated_TPM':True,
            'round_context_to_checkpoint_wall_seconds':(datetime.fromisoformat(checkpoint['created_at'].replace('Z','+00:00'))-datetime.fromisoformat(context['issued_at'].replace('Z','+00:00'))).total_seconds(),
            'wall_scope':'includes local client startup/training, transfer/files, current admission and predecessor replay; excludes pre-context attestation and final campaign verification; not an isolated detector benchmark',
            'validation':metrics})
result={'profile':'fixed-live-envelope-endpoints-v1','protocol_sha256':sha256_file(root/'reserved-protocol-before-training.json'),
        'evaluation_split':'validation','test_used':False,'rounds':allrows,
        'totals':{b:{'intercepted':sum(r['current_poisoned_updates_intercepted'] for r in allrows if r['branch']==b),
                     'currently_poisoned':sum(r['poisoned_current_updates'] for r in allrows if r['branch']==b),
                     'benign_current_excluded':sum(r['benign_current_updates_excluded'] for r in allrows if r['branch']==b),
                     'peak_validation_full_trigger_asr':max(r['validation']['complete_trigger']['asr'] for r in allrows if r['branch']==b),
                     'final_validation_full_trigger_asr':next(r['validation']['complete_trigger']['asr'] for r in allrows if r['branch']==b and r['round']==5)} for b in protocol['branches']}}
save(root/'reports/fixed-endpoint-evaluation.json',result)
print(json.dumps(result['totals']),flush=True)
