"""Verify the intentional failure using failed-round, rather than checkpoint assertions."""
from pathlib import Path
import torch
torch.set_num_threads(1)
from revision_dba_experiment import save
from fl_forensics.in_round_admission import verify_in_round_secure_round
from fl_forensics.storage import load_json
from fl_forensics.canonical import sha256_file
root=Path('/evidence');workspace=root/'branches/clean/rounds/round-001'
report=verify_in_round_secure_round(workspace=workspace,trust_workspace=root/'trust',
    submissions_root=workspace/'submissions',validation_split_path=root/'partition/server/splits/validation.json',
    client_receipts=workspace/'client-receipts',require_derivation=True)
assert report['status']=='verified' and report['round_status']=='failed_without_checkpoint'
assert report['admission_decisions_verified'] and report['decisions_recomputed'] and report['trust_recomputed']
assert not report['coefficients_verified'] and report['property_statuses']['coefficients']=='not_defined_without_checkpoint'
assert report['accepted_count']==0 and report['quarantined_count']==15 and not (workspace/'checkpoint/manifest.json').exists()
audit=load_json(workspace/'observable-policy-result.json')
assert not audit['decision']['supported'] and audit['decision']['proposal_quorum_satisfied']
decisions=[load_json(p)['core'] for p in (workspace/'in-round-decisions').glob('*.json')]
assert len(decisions)==15 and all(float(d['effective_weight_decimal'])==0 and d['trust']['admissible'] for d in decisions)
result={'status':'verified','fresh_valid_quotes':15,'real_unmodified_local_trainings':15,
        'valid_TPM_update_bundles':15,'all_mandatory_gates_pass':True,'statistical_context_supported':False,
        'head_proposed_quorum_before_live_adapter':True,'live_positive_masses':0,'checkpoint_created':False,
        'state_support_distances':audit['state_support_distances'],
        'observable_result_sha256':sha256_file(workspace/'observable-policy-result.json'),
        'full_verification':report,
        'runner_incident':'The generic success-round runner incorrectly required coefficients_verified=true. The verifier itself succeeded and correctly reported coefficients not defined without a checkpoint. This specialized closure adds no training, changes no signed input and does not invent coefficients.'}
save(root/'reports/negative-case-verification.json',result)
print('UNSUPPORTED-CONTEXT LIVE FAILURE VERIFIED',flush=True)
