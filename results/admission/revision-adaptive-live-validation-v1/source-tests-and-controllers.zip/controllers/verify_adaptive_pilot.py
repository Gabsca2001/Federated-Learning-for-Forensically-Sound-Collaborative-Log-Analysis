"""Repeat every real local endpoint and every finite adaptive query."""
from pathlib import Path
import copy
import json
import sys
import numpy as np

out=Path(__file__).parent
sys.path[:0]=[str(out.parent/'state-conditioned-detector-20261103'),str(out.parent/'geometry-detector-20261103')]
from policy_data import Generator,current_observation,aggregate_selected
from revision_dba_experiment import model_with_arrays,outcomes,predict,authenticate,save
from fl_forensics.byzantine import model_delta
from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
from fl_forensics.persistent_envelope_policy import PersistentEnvelopePolicy
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.sequential_decision import digest
from fl_forensics.state_conditioned_audit import load_model,residual_scores

repo=Path.cwd();lab=repo/'artifacts/revision-adaptive-model-pilot-v2'
protocol=json.loads((lab/'protocol-before-training.json').read_bytes())
assert sha256_file(out/'adaptive_model_pilot_v2.py')==protocol['controller_sha256']
cfg=json.loads((repo/'artifacts/revision-dba-three-seed-v1/distributed-s341593/protocol-before-training.json').read_bytes())
calroot=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
cal=json.loads((calroot/'non-iid.json').read_bytes());env=json.loads((calroot/'non-iid-envelope.json').read_bytes())
assert sha256_file(calroot/'non-iid.json')==protocol['calibration_sha256']
assert sha256_file(calroot/'non-iid-envelope.json')==protocol['envelope_sha256']
modelroot=repo/'artifacts/revision-state-conditioned-heldout-v1/models/non-iid'
models={v:load_model(modelroot/f'{v}.npz') for v in ('conditioned','state-disabled')}
assert all(sha256_file(modelroot/f'{v}.npz')==protocol['predictors'][v] for v in models)
gen=Generator(repo/'artifacts/m3-data24-parquet-non-iid',cfg)
masses={c:len(gen.rows[c]) for c in gen.clients}
validation=json.loads(Path(cfg['validation_path']).read_bytes())['rows']['validation']
initial_pred,_=predict(gen.initial,validation,gen.deps)
correct=[p==r['label'] for p,r in zip(initial_pred,validation,strict=True)]
plan=DistributedBackdoorPlan.model_validate(protocol['attack_plan'])
attackers=protocol['attackers_for_generation_only'];seed=protocol['seed']
counts={'local_training_calls_repeated':0,'queries_repeated':0,'round_aggregates_repeated':0}
comparison=[]
def read(p):return json.loads(p.read_bytes())
def score(base,exports,policy,number):
    base_arrays=arrays_from_export(base,np=np)
    obs=current_observation(base,[model_delta(base_arrays,arrays_from_export(e,np=np)) for e in exports],gen.clients,{})
    obs.pop('source',None);obs['cohort_id']=sha256_file(gen.root/'manifest.json')
    scored={v:residual_scores(obs,m) for v,m in models.items()}
    support=all(scored[v]['state_support_distance'][0]<=min(cal['state_support_limits'][v],env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in models)
    risk={v:scored[v]['risk'][0].tolist() for v in models}
    pin=digest({'base':sha256_bytes(derived_json_bytes(base)),'updates':[sha256_bytes(derived_json_bytes(e)) for e in exports]})
    result=policy.step(number,risk,context_supported=support,mandatory_gate=dict.fromkeys(gen.clients,True),masses=masses,
        expected_previous_digest=policy.head,source_observation_sha256=pin)
    return result,risk,support,pin

for arm in protocol['arms']:
    case=lab/arm;authenticate(case,sha256_file(case/'manifest.json'))
    policy=ClientEnvelopePolicy(cal,env);bounded=PersistentEnvelopePolicy(cal,env)
    base=gen.initial
    for number in range(1,protocol['horizon']+1):
        target=case/'rounds'/f'round-{number:03d}';record=read(target/'round.json')
        assert read(target/'base-model.json')==base
        if arm=='matched-clean-active':
            _,_,exports,_=gen.execute(base,seed,number);counts['local_training_calls_repeated']+=15
            decision,risk,support,pin=score(base,exports,policy,number)
        else:
            _,_,poison,_=gen.execute(base,seed,number,plan)
            _,_,clean,_=gen.execute(base,seed,number);counts['local_training_calls_repeated']+=30
            for role,items in [('clean',clean),('poison',poison)]:
                for c,e in zip(gen.clients,items,strict=True):assert read(target/'endpoint-training'/role/f'{c}.json')==e
            ca=[arrays_from_export(e,np=np) for e in clean];pa=[arrays_from_export(e,np=np) for e in poison]
            candidates=[];transcript=read(target/'query-transcript.json')
            for alpha,row in zip(protocol['alphas'],transcript,strict=True):
                assert alpha==row['alpha']
                exports=[model_with_arrays(clean[i],[a+alpha*(b.astype(np.float64)-a) for a,b in zip(ca[i],pa[i],strict=True)]) if c in attackers else clean[i] for i,c in enumerate(gen.clients)]
                trial=copy.deepcopy(policy);decision,risk,support,pin=score(base,exports,trial,number)
                assert decision==row['decision']
                aggregate=aggregate_selected(gen,base,exports,decision['quarantine_current_round']) if support else None
                asr=outcomes(aggregate,validation,plan,correct,gen.deps)['complete_trigger']['asr'] if aggregate is not None else -1.
                assert asr==row['validation_full_trigger_asr']
                q=len(set(decision['quarantine_current_round'])&set(attackers))
                excess=min(decision['clients'][c]['client_envelope_current_minimum_excess'] for c in attackers)
                suppressed=sum(decision['clients'][c]['client_envelope_retreat_detected'] for c in attackers)
                assert (q,excess,suppressed)==(row['attackers_quarantined'],row['minimum_attacker_excess'],row['suppressed_attackers'])
                if aggregate is not None:candidates.append(((-q,excess if number==1 else suppressed,asr,-alpha),alpha,exports,trial,decision,risk,support,pin))
                counts['queries_repeated']+=1
            _,alpha,exports,policy,decision,risk,support,pin=max(candidates,key=lambda item:item[0])
            assert alpha==record['alpha']
        assert decision==read(target/'decision.json')
        for c,e in zip(gen.clients,exports,strict=True):assert read(target/'updates'/f'{c}.json')==e
        aggregate=aggregate_selected(gen,base,exports,decision['quarantine_current_round'])
        assert read(target/'global-model.json')==aggregate
        assert outcomes(aggregate,validation,plan,correct,gen.deps)==record['validation']
        diagnostic=bounded.step(number,risk,context_supported=support,mandatory_gate=dict.fromkeys(gen.clients,True),masses=masses,
            expected_previous_digest=bounded.head,source_observation_sha256=pin)
        comparison.append({'arm':arm,'round':number,'old_quarantines':decision['quarantine_current_round'],
                           'bounded_proposals_on_frozen_old_trajectory':diagnostic['quarantine_current_round'],
                           'qualification':'Diagnostic policy replay on the unchanged old-policy bases and local updates, not a new active defense trajectory or an ASR mitigation result.'})
        counts['round_aggregates_repeated']+=1;base=aggregate
        print(json.dumps({'verified_arm':arm,'round':number}),flush=True)
result={'status':'verified','protocol_sha256':sha256_file(lab/'protocol-before-training.json'),**counts,'diagnostic_comparison':comparison}
save(lab/'verification.json',result);(out/'adaptive-pilot-verification.json').write_bytes((lab/'verification.json').read_bytes())
print(json.dumps(counts),flush=True)
