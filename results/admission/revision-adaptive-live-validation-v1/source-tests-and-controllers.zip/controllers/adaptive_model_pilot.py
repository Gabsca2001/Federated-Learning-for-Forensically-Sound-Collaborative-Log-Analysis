"""Bounded white-box model-update search; separate from live TPM validation."""
from pathlib import Path
import copy
import json
import sys
import numpy as np

out=Path(__file__).parent
sys.path.insert(0,str(out.parent/'state-conditioned-detector-20261103'))
sys.path.insert(0,str(out.parent/'geometry-detector-20261103'))
from policy_data import Generator, current_observation, aggregate_selected
from revision_dba_experiment import save, model_with_arrays, outcomes, predict
from fl_forensics.byzantine import model_delta
from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.sequential_decision import digest
from fl_forensics.state_conditioned_audit import load_model,residual_scores

repo=Path.cwd();lab=repo/'artifacts/revision-adaptive-model-pilot-v1'
assert not lab.exists(), 'Reserved execution is one-shot; preserve partial evidence on failure'
lab.mkdir()
alphas=[0.,.03125,.0625,.125,.25,.5,.75,1.,1.5,2.]
attackers=['client02','client07','client13'];seed=551593;horizon=6
cfg=json.loads((repo/'artifacts/revision-dba-three-seed-v1/distributed-s341593/protocol-before-training.json').read_bytes())
plan=DistributedBackdoorPlan.model_validate({**cfg['attack_plan'],'seed':seed,
    'client_components':dict(zip(attackers,[[13],[17],[24]],strict=True)), 'attack_rounds':list(range(1,horizon+1))})
calroot=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
cal=json.loads((calroot/'non-iid.json').read_bytes());env=json.loads((calroot/'non-iid-envelope.json').read_bytes())
modelroot=repo/'artifacts/revision-state-conditioned-heldout-v1/models/non-iid'
models={v:load_model(modelroot/f'{v}.npz') for v in ('conditioned','state-disabled')}
protocol={'profile':'bounded-whitebox-update-interpolation-v1','seed':seed,'horizon':horizon,'alphas':alphas,
    'attackers_for_generation_only':attackers,'attack_plan':plan.model_dump(mode='json'),
    'arms':['matched-clean-active','adaptive-active-retreat'],
    'attack_budget':'Every adaptive round trains all 15 poisoned/ordinary local endpoints and all 15 unmodified endpoints from the actual current defended base; only the three attacker exports are interpolated/extrapolated. Ten candidates per round. No unseen test data.',
    'selection':'Require supported context and quorum. Prefer candidates whose three attackers are all currently permitted. At R1 maximize the minimum positive attacker envelope excess, then validation full-trigger ASR, then smaller alpha. At later rounds maximize the count of current-high attacker excesses suppressed by the historical episode peak, then validation full-trigger ASR, then smaller alpha. If no attacker-permitted candidate exists, minimize attacker quarantines before the same objective. If no supported quorum exists, halt and report.',
    'information_budget':'White-box frozen predictor/calibration and exact policy state; up to ten validation-ASR queries per round. This deliberately privileged attack search is not the blind detector input path.',
    'detector_inputs':'Only current global/local models and frozen clean calibration; no attack identities or private rows are passed to residual_scores or policy.step.',
    'interpretation':'A finite pilot can demonstrate realizable evasion for the specified search budget; it cannot establish universal adaptive security or an infinite model trajectory.',
    'new_TPM_attestation':False,'aggregation':'float64 delta FedAvg then float32 exports, offline mechanism distinct from live Flower backend',
    'implementation_sha256':implementation_sha256(),'controller_sha256':sha256_file(Path(__file__)),
    'calibration_sha256':sha256_file(calroot/'non-iid.json'),'envelope_sha256':sha256_file(calroot/'non-iid-envelope.json'),
    'predictors':{v:sha256_file(modelroot/f'{v}.npz') for v in models}}
save(lab/'protocol-before-training.json',protocol)
(out/'adaptive-pilot-protocol.json').write_bytes((lab/'protocol-before-training.json').read_bytes())
gen=Generator(repo/'artifacts/m3-data24-parquet-non-iid',cfg)
masses={c:len(gen.rows[c]) for c in gen.clients}
validation=json.loads(Path(cfg['validation_path']).read_bytes())['rows']['validation']
initial_pred,_=predict(gen.initial,validation,gen.deps)
reference_correct=[p==r['label'] for p,r in zip(initial_pred,validation,strict=True)]

def score(base,exports,policy,number):
    base_arrays=arrays_from_export(base,np=np)
    deltas=[model_delta(base_arrays,arrays_from_export(e,np=np)) for e in exports]
    obs=current_observation(base,deltas,gen.clients,{})
    obs['cohort_id']=sha256_file(gen.root/'manifest.json')
    scored={v:residual_scores(obs,m) for v,m in models.items()}
    support=all(scored[v]['state_support_distance'][0] <= min(cal['state_support_limits'][v],env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in models)
    source=digest({'base':sha256_bytes(derived_json_bytes(base)),
                   'updates':[sha256_bytes(derived_json_bytes(e)) for e in exports]})
    result=policy.step(number,{v:scored[v]['risk'][0].tolist() for v in models},
        context_supported=support,mandatory_gate=dict.fromkeys(gen.clients,True),masses=masses,
        expected_previous_digest=policy.head,source_observation_sha256=source)
    return result

summaries=[]
for arm in protocol['arms']:
    case=lab/arm;save(case/'generation-protocol.json',{'protocol_sha256':sha256_file(lab/'protocol-before-training.json'),'arm':arm})
    base=gen.initial;policy=ClientEnvelopePolicy(cal,env);rounds=[]
    for number in range(1,horizon+1):
        target=case/'rounds'/f'round-{number:03d}';save(target/'base-model.json',base)
        queries=[]
        if arm=='matched-clean-active':
            _,_,exports,training=gen.execute(base,seed,number)
            decision=score(base,exports,policy,number);alpha=None;local_calls=15
        else:
            _,_,poison,poison_training=gen.execute(base,seed,number,plan)
            _,_,clean,clean_training=gen.execute(base,seed,number)
            for role,endpoints in [('clean',clean),('poison',poison)]:
                for c,e in zip(gen.clients,endpoints,strict=True):save(target/'endpoint-training'/role/f'{c}.json',e)
            clean_arrays=[arrays_from_export(e,np=np) for e in clean]
            poison_arrays=[arrays_from_export(e,np=np) for e in poison]
            candidates=[]
            for alpha in alphas:
                exports=[model_with_arrays(clean[i],[a+alpha*(b.astype(np.float64)-a) for a,b in zip(clean_arrays[i],poison_arrays[i],strict=True)]) if c in attackers else clean[i] for i,c in enumerate(gen.clients)]
                trial=copy.deepcopy(policy);decision=score(base,exports,trial,number)
                excluded=decision['quarantine_current_round']
                result=aggregate_selected(gen,base,exports,excluded) if decision['supported'] else None
                metric=outcomes(result,validation,plan,reference_correct,gen.deps) if result is not None else None
                q=len(set(excluded)&set(attackers))
                suppressed=sum(decision['clients'][c]['client_envelope_retreat_detected'] for c in attackers)
                excess=min(decision['clients'][c]['client_envelope_current_minimum_excess'] for c in attackers)
                asr=metric['complete_trigger']['asr'] if metric is not None else -1.
                key=(-q,excess if number==1 else suppressed,asr,-alpha)
                record={'alpha':alpha,'decision':decision,'suppressed_attackers':suppressed,'minimum_attacker_excess':excess,
                        'validation_full_trigger_asr':asr,'feasible':result is not None,'attackers_quarantined':q}
                queries.append(record)
                if result is not None:candidates.append((key,alpha,exports,trial,decision))
            save(target/'query-transcript.json',queries)
            if not candidates:
                save(target/'halted.json',{'reason':'No supported quorum in the fixed query budget','queries':len(queries)})
                break
            _,alpha,exports,policy,decision=max(candidates,key=lambda item:item[0])
            training={'clean':clean_training,'poison':poison_training};local_calls=30
        save(target/'decision.json',decision)
        for c,e in zip(gen.clients,exports,strict=True):save(target/'updates'/f'{c}.json',e)
        result=aggregate_selected(gen,base,exports,decision['quarantine_current_round']) if decision['supported'] else None
        if result is None:
            save(target/'halted.json',{'reason':'No supported quorum'});break
        metric=outcomes(result,validation,plan,reference_correct,gen.deps)
        save(target/'global-model.json',result)
        record={'round':number,'alpha':alpha,'decision_digest':decision['decision_digest'],
                'quarantined':decision['quarantine_current_round'],
                'current_high_but_peak_suppressed':[c for c in attackers if decision['clients'][c]['client_envelope_retreat_detected']],
                'local_training_calls':local_calls,'queries':len(queries),'training':training,'validation':metric,
                'base_model_sha256':sha256_file(target/'base-model.json'),'global_model_sha256':sha256_file(target/'global-model.json')}
        save(target/'round.json',record);rounds.append(record);base=result
        print(json.dumps({'arm':arm,'round':number,'alpha':alpha,'quarantined':record['quarantined'],
                          'peak_suppressed':record['current_high_but_peak_suppressed'],'asr':metric['complete_trigger']['asr']}),flush=True)
    gen.close(case)
    summaries.append({'arm':arm,'rounds':rounds,'manifest_sha256':sha256_file(case/'manifest.json')})
save(lab/'summary.json',{'protocol_sha256':sha256_file(lab/'protocol-before-training.json'),'arms':summaries})
(out/'adaptive-pilot-results.json').write_bytes((lab/'summary.json').read_bytes())
print('BOUNDED ADAPTIVE PILOT COMPLETE',flush=True)
