"""Close this bounded validation step with explicit scientific qualifications."""
from pathlib import Path
import difflib
import json
import re
import shutil
import xml.etree.ElementTree as ET
import zipfile
import numpy as np

from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.crypto import SoftwareECDSASigner,load_public_key,verify_digest_signature
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.storage import write_once

repo=Path.cwd();out=Path(__file__).parent
main=repo/'artifacts/revision-live-envelope-tpm-v2'
negative=repo/'artifacts/revision-live-envelope-unsupported-v1'
adaptive=repo/'artifacts/revision-adaptive-model-pilot-v2'
tamper=repo/'artifacts/revision-live-envelope-tamper-v1'
dest=repo/'results/revision-adaptive-live-validation-v1'
dest.mkdir(exist_ok=True,parents=True)
def read(p):return json.loads(p.read_bytes())
def save(p,v):
    p.parent.mkdir(exist_ok=True,parents=True)
    write_once(p,derived_json_bytes(v))
def md(p,text):
    p.parent.mkdir(exist_ok=True,parents=True);p.write_text(text)

before=read(out/'before.json')
assert implementation_sha256()=='9756ea7efd479992a9aecfc45953b476131e1ad9edfa0bfae32032db50839ff7'
assert read(main/'reserved-protocol-before-training.json')['implementation_sha256']==implementation_sha256()
assert 'LIVE ENVELOPE TPM CASE COMPLETED' in (out/'live-run-v2.log').read_text()
assert sha256_file(repo/'.git/index')==before['git_index_sha256']
thesis=read(out.parent/'formal-closure-20261103/before-review.json')
assert all(sha256_file(Path(thesis['thesis_root'])/n)==h for n,h in thesis['thesis_sources'].items())
suite=ET.parse(out/'final-full-tests.xml').getroot().find('testsuite')
assert int(suite.attrib['tests'])==652 and suite.attrib['failures']==suite.attrib['errors']=='0'
for branch in ('clean','shadow','active'):
    report=read(main/'reports'/f'{branch}-campaign-verification.json')
    assert report['status']=='verified', report
assert read(negative/'reports/negative-case-verification.json')['status']=='verified'
assert read(adaptive/'verification.json')['local_training_calls_repeated']==270
assert all(c['status']!='verified' for c in read(tamper/'summary.json')['cases'])

copies={
    'live-fixed-endpoints.json':main/'reports/fixed-endpoint-evaluation.json',
    'live-negative-verification.json':negative/'reports/negative-case-verification.json',
    'live-tamper-verification.json':tamper/'summary.json',
    'live-runtime-image.json':main/'runtime-image.json',
    'adaptive-pilot-verification.json':adaptive/'verification.json',
    'adaptive-pilot-results-v2.json':adaptive/'summary.json',
}
for name,p in copies.items():
    if (out/name).exists():assert (out/name).read_bytes()==p.read_bytes()
    else:shutil.copyfile(p,out/name)
live=read(out/'live-fixed-endpoints.json');pilot=read(adaptive/'summary.json')
last_models=[read(adaptive/arm/'rounds/round-006/global-model.json') for arm in ('matched-clean-active','adaptive-active-retreat')]
l2=float(np.linalg.norm(np.concatenate([(a.astype(np.float64)-b).ravel() for a,b in zip(*[arrays_from_export(m,np=np) for m in last_models],strict=True)])))
peaks={r['arm']:max(x['validation']['complete_trigger']['asr'] for x in r['rounds']) for r in pilot['arms']}
finals={r['arm']:r['rounds'][-1]['validation']['complete_trigger']['asr'] for r in pilot['arms']}
test_summary={k:suite.attrib[k] for k in ('tests','failures','errors','skipped','time')}
facts={'profile':'bounded-adaptive-live-validation-summary-v1','implementation_sha256':implementation_sha256(),
       'package_file_count':len(list((repo/'src/fl_forensics').glob('*.py'))),
       'tests':test_summary,'live_round_instances':15,'live_successful_trajectories':3,'rounds_per_live_trajectory':5,
       'live_positive_case_fresh_quotes':225,'live_positive_case_local_trainings':225,
       'live_negative_case_fresh_quotes':15,'live_negative_case_local_trainings':15,
       'live_total_validated_fresh_quotes':240,'live_total_local_trainings':240,
       'live_case_totals':live['totals'],'live_mutations_rejected':5,
       'adaptive_trajectories':2,'adaptive_rounds_per_trajectory':6,'adaptive_generation_trainings':270,
       'adaptive_verification_trainings':270,'adaptive_queries_generated_and_repeated':60,
       'adaptive_peak_validation_full_trigger_asr':peaks,'adaptive_final_validation_full_trigger_asr':finals,
       'adaptive_final_parameter_L2_vs_matched_clean':l2,
       'development_bounded_candidates_promoted':False,'production_head':'client-envelope-retreat-policy-v1',
       'failed_attempts':[
           {'case':'live-v1 bootstrap','training_calls':0,'quotes':0,'reason':'Measured historical Dockerfile missing from the first image; partial private trust workspace retained.'},
           {'case':'live-v1 configuration mismatch','training_calls':0,'valid_quotes':15,'reason':'Old full-config partition lock rejected changed training fields before training; original attempt and source retained.'},
           {'case':'adaptive-v1 export schema','training_calls':15,'reason':'Controller exported a forbidden source field before its first detector query; partial artifacts and old controller retained.'},
           {'case':'negative success-runner assertion','additional_training_calls':0,'reason':'Verifier succeeded for an intentionally failed round, but generic runner demanded checkpoint coefficients. Specialized closure verifies their absence.'}],
       'thesis_source_files_unchanged':len(thesis['thesis_sources']),'git_index_unchanged':True,
       'limitations':{'universal_adaptive_security':False,'perfect_current_poisoning_detection':False,
           'live_ASR_mitigation_demonstrated_in_this_case':False,'physical_TPM':False,
           'independent_witness_or_time':False,'test_split_used':False,'ToN_IoT_used':False,
           'automatic_client_ban':False,'new_group_collusion_proof':False}}
save(out/'VALIDATION_SUMMARY.json',facts)

report=f'''# Bounded adaptive and live-TPM validation — 3 November 2026

The retreat envelope now runs inside the signed live admission path, before
aggregation. Its observed adaptive limitation remains unresolved. The new
bounded-persistence candidates are retained as experimental code and were not
promoted after failing the predeclared development guardrail. This step does not
claim reliable automatic identification of malicious clients.

## Version and scope

Parent formal completion: `ca48267410724f4ddb20fbc0226e486f143b562527fde5411f416844f653cb91`.
Current {facts['package_file_count']}-file package: `{implementation_sha256()}`.
Full suite: **652 tests passed**, two existing Typer deprecation warnings.
The source archive includes the preceding releases. Historical evidence is
verified under its preserved release and is never re-signed as current evidence.
The thesis, Git index and deferred ToN-IoT work are unchanged.

## Development result: persistence is not sufficient evidence of current poisoning

The experiment was frozen before scoring 48 previously used development cases.
Frozen clean predictors, global references and individual envelopes were kept
unchanged. Ground-truth identities were used only for evaluation and candidate
selection on these development cases, never by the detector.

| Candidate on old trajectories | Poisoned updates proposed for quarantine | Never-attacker updates | Currently clean scheduled-attacker updates |
|---|---:|---:|---:|
| Existing retreat policy | 452 | 0 | 0 |
| Retreat plus confirmation after 2 high rounds | 476 | 0 | 1 |
| Retreat plus confirmation after 3 high rounds | 474 | 0 | 1 |
| Retreat plus confirmation after 4 high rounds | 472 | 0 | 1 |

All new candidates failed the criterion requiring no such false interventions
and no quorum loss. These are conditional replays over old trajectories, not new
active-defense efficacy estimates. The one event is IID development seed
463593, stream-012, client12 at round 15, after the scheduled attack ended at
round 14. Current unmodified training still reacts to a contaminated shared
base. Its two risks, 0.8186864 and 0.7559457, exceed clean limits 0.7707873 and
0.7437924. The old retreat channel releases it; persistence alone does not.

The additional policy has a narrow mathematical guarantee: for an eligible
client in supported, ordered observations, K consecutive positive dual-view
client-envelope excesses trigger its bounded channel by the Kth observation,
independently of earlier peak magnitude. A non-high or unsupported observation
resets that channel. This says nothing about semantic malice. False-positive
free release on every unmodified update does not follow from this premise.

## Real adaptive model-update pilot

Two matched non-IID six-round CPU trajectories use seed 551593 and fixed
attackers client02/client07/client13. The adaptive adversary knows the frozen
policy and predictor. Each round really trains 15 poisoned/ordinary endpoints
and 15 unmodified endpoints, then searches ten fixed interpolation or
extrapolation factors for the three attacker updates. Candidate ASR queries use
validation data. The detector sees only model observations and clean references.
This privileged search and post-training manipulation are **offline**, without
new TPM signatures or a claim of an undetected live training-contract bypass.

Client07 and client13 retain positive current excess while their initial peak
suppresses quarantine in rounds 2–6. All three submitted attacker updates remain
permitted in this pilot. Maximum full-trigger validation ASR is
**{100*peaks['adaptive-active-retreat']:.4f}%**; final ASR is
**{100*finals['adaptive-active-retreat']:.4f}%**, versus zero throughout the matched
clean trajectory. Final parameter L2 difference from matched clean is
**{l2:.9f}**. Small ASR does not establish recovery of clean model state.

All **270 local trainings, 60 candidate searches and 12 aggregates** were
independently repeated and matched the retained models, decisions and metrics.
The three-round bounded candidate would propose client07/client13 from round 3
on these frozen old-policy updates. That diagnostic does not predict its active
future bases or prove ASR mitigation, and does not override its development
failure. A finite six-round pilot establishes this bounded evasion example,
not an infinite realizable trajectory or security against every adaptive attack.

## Fresh live integration with swtpm

Three separate five-round trajectories use a new non-IID training seed 541593:
clean training with the policy enforced; DBA with authenticated statistical
proposals recorded but unapplied; and DBA with the proposals enforced. All start
from the same retained model. Three DBA rounds followed by two clean
continuations exercise confirmation, exclusion, release and predecessor replay.
They are **15 round instances, not one 15-round chain**.

The case contains **225 fresh verified swtpm Quotes and 225 local trainings**.
Every round and all three final campaigns verify under the retained image.
The active arm excludes client07/client13 at rounds 2 and 3: **4/9 currently
poisoned updates**, with no observed currently benign exclusions. Client02 is
missed. The clean arm excludes no client. Every fixed full-trigger validation
ASR is zero in all three arms, including the unapplied-proposal control.
Consequently this is a mechanism and integration validation, **not evidence of
an ASR advantage**. Full/component-trigger, clean utility and scope-qualified
wall-time measurements are retained for all endpoints in
[live-fixed-endpoints.json](live-fixed-endpoints.json).

Each node uses its own TPM state, socket, partition and output. The head reads
verified public/local models, not raw client rows. In the live adapter the head
shares the coordinator process; process-level denial of coordinator access to
raw partitions is not claimed. Quote measurements cover the declared components,
not a physical TPM, an entire host or independently verified wall-clock time.

The integration binds the four frozen predictor/calibration assets in the
signed training context. The audit-result digest appears in the signed primary
decisions; those decisions determine the actual checkpoint inputs and masses.
Verification recomputes the current frame and policy history and verifies the
predecessor rounds. Full campaign verification additionally checks the model
and checkpoint chain. The complete authenticated prefix and its submissions,
client receipts, frozen assets and trust records are required inputs; a lone
signed checkpoint is insufficient. Auxiliary old composite statistics are
retained for inspection, but do not select the new primary decision. Its binary
score is a block indicator, not a probability of malice.

An explicit partition/training binding now allows only `seed`, `local_epochs`
and `rounds` to change against the exact original partition configuration.
Partitioning, model settings and all other fields must remain equal. Both
configurations and the declared differences are bound to the signed context.
The exact old partition hash and client/model schema remain mandatory; no
unverified cohort-ID remapping is performed. A genesis model is separately
schema/finite checked and its exact bytes are bound as the signed base model.

## Real failure without a checkpoint

A separate one-round negative case starts from a schema-valid zero model,
outside the frozen state-support range: distance 7.1259948 versus limit
2.4604774. It adds **15 fresh valid Quotes, 15 unmodified local trainings and
15 valid TPM-signed bundles**. All mandatory gates pass. The statistical head
abstains and still exposes eligible proposed mass, but the live adapter assigns
zero final mass to every contribution and creates **no checkpoint**.

The failed-round verifier reconstructs trust, statistical results, decisions
and derivation with zero errors. Coefficients correctly remain
`not_defined_without_checkpoint`; they are not falsely marked verified.
This conservative complete-cohort profile also aborts on missing or failed
mandatory gates. That is an availability tradeoff; no calibrated partial-cohort
operation is claimed. Quorum failure never restores rejected contribution mass.

Five additional mutations on disposable copies of the valid active campaign
are rejected: current audit result, predecessor audit history, client bundle
signature, signed final mass and predecessor checkpoint. The unmodified copy
verifies, and original signed evidence is unchanged.

## Formal and thesis boundaries

The preceding formal correspondence remains a versioned historical milestone.
The new live profile adds finite evidence for mandatory-gate non-compensation,
actual mass enforcement, asset/history binding and unsupported-context failure.
It does not turn empirical anomaly detection into a semantic truth theorem.
The old single-round rescoring adapter explicitly rejects this new cohort-bound
profile; frozen historical decisions remain a distinct supported analysis.

Receipt completeness remains conditional on supplied retained client receipts.
There is no independent append-only witness, trusted deadline or delivery
guarantee. Blast radius remains structural reachability over the supplied
authenticated artifact set, separate from numerical/causal replay. This step
adds no group-collusion proof, physical TPM campaign or ToN-IoT evaluation.

The professor's retrospective group requirement remains separate from this
optional automatic-quarantine research. This result must be written as an
implemented and tested live mechanism with a demonstrated adaptive limitation,
not as validated reliable automatic client exclusion. A quantitative live
mitigation claim would still require an attack-effective matched control and a
longer separately declared efficacy campaign. Any revised automatic rule must
also address clean responses to contaminated states and be evaluated on newly
reserved active trajectories after freezing its calibration and error budget.

## Reproduction and incidents

The source/test/controller archive, exact image ID and local frozen image tar
are retained, with source and artifact digests. Earlier attempts are preserved:
one image omitted a declared measured Dockerfile; the first initialization
rejected the full-config partition mismatch before training; an offline export
schema error stopped after 15 clean trainings and before its first detector
query. The negative-case generic runner demanded checkpoint coefficients even
though the verifier correctly accepted a failed round; a specialized closure
checks their absence without retraining or altering evidence. None of these
attempts is counted as a successful primary trajectory.

The final closure is signed by a local software analyst key. It is an integrity
record, not independent timestamping, TPM signing of the analysis, or external
scientific certification. See [VALIDATION_SUMMARY.json](VALIDATION_SUMMARY.json).
'''
md(out/'VALIDATION_REPORT.md',report)
md(repo/'docs/LIVE_ENVELOPE_VALIDATION.md', report.replace('](live-fixed-endpoints.json)','](../results/revision-adaptive-live-validation-v1/live-fixed-endpoints.json)').replace('](VALIDATION_SUMMARY.json)','](../results/revision-adaptive-live-validation-v1/VALIDATION_SUMMARY.json)'))
md(repo/'docs/PERSISTENT_ENVELOPE_POLICY.md', '''# Experimental bounded-persistence envelope

`PersistentEnvelopePolicy` preserves the original retreat/global channels and
adds K consecutive supported, positive individual-envelope observations as a
peak-independent proposal. K is one of 2, 3, 4. This provides a conditional
confirmation bound and retains mandatory rejection, prefix ordering, exact
retries, review-only accumulated evidence and quorum bookkeeping.

All three development candidates failed the declared no-false-currently-clean
proposal criterion. The class is retained for reproducible experiments and unit
checks; it is not used by `live-client-envelope-retreat-v1`. The live profile
continues to use `ClientEnvelopePolicy`. See
[the validation report](LIVE_ENVELOPE_VALIDATION.md) for the real adaptive
counterexample, the development failure and the actual live integration scope.
''')
for name in ('STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md','FORMAL_PROFILE_CORRESPONDENCE.md'):
    path=repo/'docs'/name
    snapshot=out/'before-docs'/name;snapshot.parent.mkdir(exist_ok=True);shutil.copyfile(path,snapshot)
    with path.open('a') as stream:
        stream.write('\n\n## Bounded live-envelope validation — 3 November 2026\n\n'
            'The separate observable-envelope live profile now has a fresh swtpm integration case, '
            'an authenticated unsupported-context failure and five rejected tamper cases. '
            'The current full suite passes 652 tests. The real adaptive pilot demonstrates '
            'peak suppression; bounded-persistence candidates failed their development guardrail '
            'and were not promoted. The five-round live control has zero ASR even without '
            'statistical quarantine, so no live ASR mitigation advantage follows. '
            'This is a new versioned empirical profile; prior formal/source closures remain preserved. '
            'The thesis and ToN-IoT remain unchanged. Details and exact evidence: '
            '[LIVE_ENVELOPE_VALIDATION.md](LIVE_ENVELOPE_VALIDATION.md).\n')

# Preserve only explicit source differences from the immediately preceding formal release.
diff=[];changed={};oldroot=repo/'artifacts/revision-adaptive-live-policy-v1/before-source/fl_forensics'
source=repo/'src/fl_forensics'
for name in sorted({p.name for p in oldroot.glob('*.py')}|{p.name for p in source.glob('*.py')}):
    old,new=oldroot/name,source/name
    if old.exists() and new.exists() and old.read_bytes()==new.read_bytes():continue
    changed[name]={'before':sha256_file(old) if old.exists() else None,'after':sha256_file(new) if new.exists() else None}
    diff.extend(difflib.unified_diff(old.read_text().splitlines(keepends=True) if old.exists() else [],new.read_text().splitlines(keepends=True) if new.exists() else [],fromfile='a/src/fl_forensics/'+name,tofile='b/src/fl_forensics/'+name))
save(out/'source-changes.json',{'before':before['implementation_sha256'],'after':implementation_sha256(),'files':changed})
md(out/'implementation.patch',''.join(diff))
snapshot=main/'current-source-release/fl_forensics';shutil.copytree(source,snapshot,ignore=shutil.ignore_patterns('__pycache__'))

with zipfile.ZipFile(out/'source-tests-and-controllers.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for folder,prefix in ((source,'src/fl_forensics'),(oldroot,'before-source/fl_forensics'),
                          (repo/'artifacts/revision-live-envelope-tpm-v1/failed-initialization-source/fl_forensics','first-attempt-source/fl_forensics')):
        for p in sorted(folder.glob('*.py')):archive.write(p,prefix+'/'+p.name)
    for name in ('test_live_envelope.py','test_persistent_envelope_policy.py','test_partition_training_binding.py'):
        archive.write(repo/'tests'/name,'tests/'+name)
    for p in sorted(out.glob('*.py')):archive.write(p,'controllers/'+p.name)
    for p in sorted((repo/'scripts').glob('revision_live_envelope*.py')):archive.write(p,'scripts/'+p.name)
    archive.write(repo/'scripts/revision_attested_dba.py','scripts/revision_attested_dba.py')
    for name in ('revision-envelope-live-trust.yaml','revision-envelope-live-trust-v2.yaml'):
        archive.write(repo/'configs'/name,'configs/'+name)
    for name in ('Dockerfile.revision-live-envelope','Dockerfile.revision-live-envelope-v2'):
        archive.write(repo/name,name)
    for p in sorted((repo/'docs').glob('*.md')):
        if p.name in ('LIVE_ENVELOPE_VALIDATION.md','PERSISTENT_ENVELOPE_POLICY.md','STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md','FORMAL_PROFILE_CORRESPONDENCE.md'):
            archive.write(p,'docs/'+p.name)
with zipfile.ZipFile(out/'source-tests-and-controllers.zip') as archive:assert archive.testzip() is None

closures={}
for root in (main,negative,adaptive,tamper):
    files={}
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if not p.is_file() or p.is_symlink() or '__pycache__' in rel.parts or 'tpm-state' in rel.parts or p.name=='validation-artifact-closure.json':continue
        if any('private' in part.lower() for part in rel.parts) or p.suffix=='.ctx':continue
        files[rel.as_posix()]=sha256_file(p)
    value={'profile':'bounded-validation-public-artifact-closure-v1','root':str(root),'files':files,
           'excluded':'Private keys, TPM private state, runtime contexts and Python caches; no authentication claims are derived from those excluded files.'}
    save(root/'validation-artifact-closure.json',value)
    save(out/(root.name+'-closure.json'),value)
    closures[str(root)]=sha256_file(root/'validation-artifact-closure.json')

for p in out.iterdir():
    if p.is_file() and p.suffix in ('.json','.md','.xml','.log','.zip','.patch','.sha256'):
        shutil.copyfile(p,dest/p.name)
shutil.copyfile(out/'VALIDATION_REPORT.md',dest/'README.md')
for name in ('LIVE_ENVELOPE_VALIDATION.md','PERSISTENT_ENVELOPE_POLICY.md','STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md','FORMAL_PROFILE_CORRESPONDENCE.md'):
    for href in re.findall(r'\]\(([^)]+\.md)\)',(repo/'docs'/name).read_text()):
        if not href.startswith(('https:','http:')):assert (repo/'docs'/href).exists(),(name,href)

signer=SoftwareECDSASigner.generate();authority=repo/'artifacts/revision-adaptive-live-authority-v1'
write_once(authority/'analyst.private.pem',signer.private_pem());write_once(out/'analyst.public.pem',signer.public_pem())
core={'profile':'bounded-adaptive-live-analyst-completion-v1','date':'2026-11-03',
      'parent_completion_sha256':before['parent_completion_sha256'],
      'implementation_sha256':implementation_sha256(),'artifact_roots':closures,'summary':facts,
      'maintained_documents':{name:sha256_file(repo/'docs'/name) for name in ('LIVE_ENVELOPE_VALIDATION.md','PERSISTENT_ENVELOPE_POLICY.md','STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md','FORMAL_PROFILE_CORRESPONDENCE.md')},
      'artifacts':{p.relative_to(out).as_posix():sha256_file(p) for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('completion-closure.json','completion-closure.sha256')},
      'authority_role':'Local software analyst; integrity closure, not independent witness/time, TPM analysis signature or external scientific certification'}
d=sha256_bytes(derived_json_bytes(core));signed={'core':core,'core_digest':d,'signature':{'key_id':signer.key_id,'value_b64':signer.sign_digest(d),'trust_level':'software-development'}}
save(out/'completion-closure.json',signed)
assert verify_digest_signature(load_public_key(signer.public_pem()),d,signed['signature']['value_b64'])
assert all(sha256_file(out/n)==h for n,h in core['artifacts'].items())
assert sha256_file(repo/'.git/index')==before['git_index_sha256']
assert all(sha256_file(Path(thesis['thesis_root'])/n)==h for n,h in thesis['thesis_sources'].items())
md(out/'completion-closure.sha256',sha256_file(out/'completion-closure.json')+'\n')
for name in ('completion-closure.json','completion-closure.sha256','analyst.public.pem'):shutil.copyfile(out/name,dest/name)
print('BOUNDED ADAPTIVE/LIVE VALIDATION SEALED',sha256_file(out/'completion-closure.json'),flush=True)
