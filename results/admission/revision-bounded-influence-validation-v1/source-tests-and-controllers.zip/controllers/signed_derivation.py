"""Post-hoc containment derivation over retained genuine swtpm-signed inputs."""
from common import *
from fl_forensics.crypto import load_public_key,verify_digest_signature
from fl_forensics.secure_round import _verify_signed
from fl_forensics.secure_round_models import UpdateBundle,SecureRoundContext
from fl_forensics.in_round_admission import verify_in_round_signature
from fl_forensics.in_round_admission_models import InRoundContributionDecision
from fl_forensics.trust import verify_enrollment_record
from fl_forensics.trust_models import EnrollmentRecord
from fl_forensics.canonical import sha256_bytes
from fl_forensics.preprocessing import derived_json_bytes

root=repo/'artifacts/revision-live-envelope-tpm-v2'
parent=out.parent/'adaptive-live-policy-20261103'
completion=read(parent/'completion-closure-v2.json');d=sha256_bytes(derived_json_bytes(completion['core']))
assert d==completion['core_digest'] and verify_digest_signature(load_public_key((parent/'analyst-v2.public.pem').read_bytes()),d,completion['signature']['value_b64'])
closure=read(root/'validation-artifact-closure.json')
assert sha256_file(root/'validation-artifact-closure.json')==completion['core']['artifact_roots'][str(root)]
def pin(path):
    assert sha256_file(path)==closure['files'][path.relative_to(root).as_posix()]
    return sha256_file(path)
authority=load_public_key((root/'trust/authority/enrollment-authority.public.pem').read_bytes())
enrolled={}
for p in (root/'trust/registry/enrollments').glob('*.json'):
    pin(p);record=EnrollmentRecord.model_validate(read(p));assert verify_enrollment_record(record,authority)
    enrolled[record.core.client_id]=record
gen,cal,env,models,rows,correct=context('non-iid');reference=read(lab/'non-iid-bounds.json');results=[]
for number in range(1,6):
    workspace=root/'branches/active/rounds'/f'round-{number:03d}'
    key=load_public_key((workspace/'public/round-coordinator.public.pem').read_bytes())
    ctx=SecureRoundContext.model_validate(read(workspace/'public/round-context.json'));assert _verify_signed(ctx,key)
    base=read(workspace/'public/base-model.json');pin(workspace/'public/base-model.json')
    exports=[];excluded=[];bindings={}
    for c in gen.clients:
        submission=workspace/'submissions'/c;bundle=UpdateBundle.model_validate(read(submission/'bundle.json'))
        assert _verify_signed(bundle,load_public_key(enrolled[c].core.esk_public_key_pem.encode()))
        assert bundle.core.context_digest==ctx.core_digest and bundle.core.base_model_sha256==ctx.core.base_model_sha256
        assert bundle.core.update_sha256==pin(submission/'update.json')
        assert bundle.core.client_id==c and bundle.core.enrollment_id==enrolled[c].enrollment_id
        decision=InRoundContributionDecision.model_validate(read(workspace/'in-round-decisions'/f'{c}.json'))
        assert verify_in_round_signature(decision,key)
        if float(decision.core.effective_weight_decimal)==0:excluded.append(c)
        else:assert float(decision.core.effective_weight_decimal)==bundle.core.num_examples
        exports.append(read(submission/'update.json'))
        bindings[c]={'original_bundle_sha256':pin(submission/'bundle.json'),'original_update_sha256':bundle.core.update_sha256,
                     'ESK_key_id':enrolled[c].core.esk_key_id,'signature_level':bundle.signature.trust_level,
                     'runtime_decision_sha256':pin(workspace/'in-round-decisions'/f'{c}.json')}
    model,report,certificate=aggregate(base,exports,gen,excluded,True,reference)
    target=lab/'signed-input-derivations'/f'round-{number:03d}'
    save(target/'source-bindings.json',bindings);save(target/'bounded-derivation.json',report)
    save(target/'removal-certificate.json',certificate);save(target/'derived-model.json',model)
    results.append({'round':number,'original_bundles_verified':15,'excluded_by_original_decisions':excluded,
                    'derived_model_sha256':sha256_file(target/'derived-model.json'),
                    'scope':'post-hoc fixed-original-input derivation, not a replacement checkpoint or new live trajectory. No new Quote, client re-signature or future retraining.'})
save(lab/'signed-input-derivation-summary.json',{'status':'verified','rounds':results,'original_files_modified':False,'new_TPM_Quotes':0})
(out/'signed-input-derivation-summary.json').write_bytes((lab/'signed-input-derivation-summary.json').read_bytes())
print('75 ORIGINAL SWTPM BUNDLES VERIFIED; SEPARATE DERIVATIONS RETAINED',flush=True)
