"""Matched white-box searches against actual aggregation, with complete replay."""
from common import *
import copy,hashlib
from fl_forensics.byzantine import model_delta
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan
from fl_forensics.round_derivation import implementation_sha256

out=Path(__file__).parent;root=lab/'adaptive';assert not root.exists();root.mkdir()
seed=551593;attackers=['client02','client07','client13'];alphas=[0.,.03125,.0625,.125,.25,.5,.75,1.,2.,4.]
tasks=[dict(strategy=s,mode=m) for s in ('envelope','bounded-envelope') for m in ('clean','adaptive')]
protocol={'profile':'clipping-aware-whitebox-v1','tasks':tasks,'horizon':6,'seed':seed,'attackers':attackers,'alphas':alphas,
    'status':'Known-seed mechanistic replication; fresh head-aware search, not a held-out seed.',
    'selection':'Ten candidates per round; require context support and quorum, maximize actual post-defense full-trigger validation ASR, then fewer attacker quarantines, then smaller alpha. No requirement that an attack evade every quarantine.',
    'information':'Frozen detector and clipping limits, exact prefix, clean and poisoned trained endpoints, validation ASR. Deliberately privileged adversary; detector uses models only.',
    'replay':'Repeat all local training, every finite candidate decision, post-clipping aggregate and validation ASR; replay the selected policy state and all bound certificates.',
    'bounds_sha256':sha256_file(lab/'non-iid-bounds.json'),'source':implementation_sha256(),
    'controller':sha256_file(Path(__file__)),'adapter':sha256_file(out/'common.py'),'test_used':False,'TPM':False}
save(root/'protocol-before-training.json',protocol)
counts=dict(generation_trainings=0,repeated_trainings=0,queries_verified=0,aggregates_verified=0);results=[]
for task in tasks:
    gen,cal,env,models,rows,correct=context('non-iid');base=gen.initial
    policy=ClientEnvelopePolicy(cal,env);verifier=ClientEnvelopePolicy(cal,env)
    reference=read(lab/'non-iid-bounds.json');bounded=task['strategy']=='bounded-envelope'
    plan=DistributedBackdoorPlan.model_validate({**gen.cfg['attack_plan'],'seed':seed,
        'client_components':dict(zip(attackers,[[13],[17],[24]],strict=True)),'attack_rounds':list(range(1,7))})
    case=root/f"{task['strategy']}-{task['mode']}";save(case/'protocol.json',task);rounds=[]
    for number in range(1,7):
        target=case/'rounds'/f'round-{number:03d}';save(target/'base-model.json',base)
        _,_,clean,_=gen.execute(base,seed,number);_,_,repeat,_=gen.execute(base,seed,number)
        assert repeat==clean;counts['generation_trainings']+=15;counts['repeated_trainings']+=15
        if task['mode']=='adaptive':
            _,_,poison,_=gen.execute(base,seed,number,plan);_,_,again,_=gen.execute(base,seed,number,plan)
            assert poison==again;counts['generation_trainings']+=15;counts['repeated_trainings']+=15
            for role,items in [('clean',clean),('poison',poison)]:
                for c,e in zip(gen.clients,items,strict=True):save(target/'endpoints'/role/f'{c}.json',e)
            ca=[arrays_from_export(e,np=np) for e in clean];pa=[arrays_from_export(e,np=np) for e in poison]
        candidates=[];queries=[]
        for alpha in alphas if task['mode']=='adaptive' else [0.]:
            exports=[model_with_arrays(clean[i],[a+alpha*(b.astype(float)-a) for a,b in zip(ca[i],pa[i],strict=True)]) if c in attackers else clean[i] for i,c in enumerate(gen.clients)] if task['mode']=='adaptive' else clean
            basearrays=arrays_from_export(base,np=np);deltas=[model_delta(basearrays,arrays_from_export(e,np=np)) for e in exports]
            pin=hashlib.sha256(b''.join(derived_json_bytes(e) for e in [base,*exports])).hexdigest()
            trial=copy.deepcopy(policy);decision,risk,args=score(base,deltas,gen,cal,env,models,trial,number,pin)
            replay=copy.deepcopy(verifier);assert replay.step(number,risk,expected_previous_digest=replay.head,**args)==decision
            aggregate_model,report,certificate=aggregate(base,exports,gen,decision['quarantine_current_round'],bounded,reference) if decision['supported'] else (None,None,None)
            metric=outcomes(aggregate_model,rows,plan,correct,gen.deps) if aggregate_model is not None else None
            q=len(set(decision['quarantine_current_round'])&set(attackers));asr=metric['complete_trigger']['asr'] if metric else -1.
            queries.append({'alpha':alpha,'decision':decision,'feasible':aggregate_model is not None,'ASR':asr,'attacker_quarantines':q})
            if task['mode']=='adaptive':counts['queries_verified']+=1
            if aggregate_model is not None:candidates.append(((asr,-q,-alpha),alpha,exports,trial,replay,decision,aggregate_model,report,certificate,metric))
        save(target/'query-transcript.json',queries)
        if not candidates:save(target/'failure.json',{'reason':'no supported quorum'});break
        _,alpha,exports,policy,verifier,decision,model,report,certificate,metric=max(candidates,key=lambda c:c[0])
        # Separate exact replay from the retained current original exports.
        for c,e in zip(gen.clients,exports,strict=True):save(target/'updates'/f'{c}.json',e)
        recomputed,rpt,cert=aggregate(base,[read(target/'updates'/f'{c}.json') for c in gen.clients],gen,decision['quarantine_current_round'],bounded,reference)
        assert recomputed==model and rpt==report and cert==certificate
        assert outcomes(recomputed,rows,plan,correct,gen.deps)==metric
        counts['aggregates_verified']+=1
        save(target/'decision.json',decision)
        if report is not None:save(target/'bounded-derivation.json',report);save(target/'removal-certificate.json',certificate)
        save(target/'global-model.json',model)
        row={'round':number,'alpha':alpha,'quarantined':decision['quarantine_current_round'],'validation':metric,
            'clipped':[c for c,v in report['contributions'].items() if any(x<1 for x in v['clipping_factors']) and v['effective_mass']!='0'] if report else []}
        save(target/'round.json',row);rounds.append(row);base=model
        print(json.dumps({'task':task,'round':number,'alpha':alpha,'ASR':metric['complete_trigger']['asr'],'quarantined':row['quarantined'],'clipped':row['clipped']}),flush=True)
    gen.close(case);results.append({'task':task,'rounds':rounds,'complete':len(rounds)==6,'manifest_sha256':sha256_file(case/'manifest.json')})
save(root/'results.json',{'cases':results,'counts':counts});(out/'adaptive-results.json').write_bytes((root/'results.json').read_bytes())
print('CLIPPING-AWARE ADAPTIVE COMPLETE',json.dumps(counts),flush=True)
