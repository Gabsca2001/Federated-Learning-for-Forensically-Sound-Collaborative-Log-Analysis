"""Exact retained-original/report/checkpoint equality and live removal certificates."""
from pathlib import Path
from fractions import Fraction
import copy,json,numpy as np
from fl_forensics.bounded_aggregation import aggregate_bounded,digest
from fl_forensics.canonical import sha256_file
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.storage import load_json,write_once
root=Path('/evidence');results=[];count=0
for branch in ('clean','active'):
    for number in range(1,6):
        w=root/'branches'/branch/'rounds'/f'round-{number:03d}'
        base=load_json(w/'public/base-model.json');basearrays=arrays_from_export(base,np=np)
        cap=load_json(w/'public/observable-assets/bounds.json')
        decisions={p.stem:load_json(p)['core'] for p in (w/'in-round-decisions').glob('*.json')}
        locals={c:arrays_from_export(load_json(w/'submissions'/c/'update.json'),np=np) for c in decisions}
        value=load_json(w/'bounded-update-derivation.json')
        for c in decisions:
            assert value['source_bundles'][c]==sha256_file(w/'submissions'/c/'bundle.json')
            assert value['source_updates'][c]==sha256_file(w/'submissions'/c/'update.json')
        pre,report=aggregate_bounded(basearrays,locals,
            masses={c:d['effective_weight_decimal'] for c,d in decisions.items()},
            mandatory_gates={c:all(ch['passed'] for ch in d['m5_checks']) for c,d in decisions.items()},
            limits=cap['limits'],reference_digest=digest(cap),minimum_contributors=8)
        assert report==value['bounded']
        expected=copy.deepcopy(base)
        for p,a in zip(expected['parameters'],pre,strict=True):p['values']=np.asarray(a,dtype=np.dtype(p['dtype'])).tolist()
        assert derived_json_bytes(expected)==(w/'checkpoint/global-model.json').read_bytes()
        actual=arrays_from_export(expected,np=np)
        epsfull=np.array([np.linalg.norm(a.astype(float)-b) for a,b in zip(actual,pre,strict=True)])
        mu=[a-b.astype(float) for a,b in zip(pre,basearrays,strict=True)];certs={}
        for c,item in report['contributions'].items():
            alpha=float(Fraction(item['normalized_weight']))
            if alpha==0:continue
            delta=[np.asarray(t['values']).reshape(t['shape']) for t in item['derived_float64_delta']]
            assert all(np.linalg.norm(d)<=C+1e-12 for d,C in zip(delta,cap['limits'],strict=True))
            other=[b.astype(float)+(m-alpha*d)/(1-alpha) for b,m,d in zip(basearrays,mu,delta,strict=True)]
            other32=[a.astype(np.float32) for a in other]
            eps=np.array([np.linalg.norm(a.astype(float)-b) for a,b in zip(other32,other,strict=True)])
            diff=np.array([np.linalg.norm(a.astype(float)-b.astype(float)) for a,b in zip(actual,other32,strict=True)])
            bound=2*alpha*np.asarray(cap['limits'])+epsfull+eps
            assert np.all(diff<=bound+1e-12)
            certs[c]={'actual_exported_distance':diff.tolist(),'bound_with_export_rounding':bound.tolist()};count+=1
        nodes=load_json(w/'derivation/manifest.json')['core']['nodes']
        assert any(n['kind']=='bounded_update_derivation' and n['sha256']==sha256_file(w/'bounded-update-derivation.json') for n in nodes)
        results.append({'branch':branch,'round':number,'checkpoint_sha256':sha256_file(w/'checkpoint/manifest.json'),
            'exact_original_to_report_to_checkpoint':True,'certificates':certs,
            'clipped_clients':[c for c,v in report['contributions'].items() if any(f<1 for f in v['clipping_factors']) and v['effective_mass']!='0']})
payload={'status':'verified','bounded_rounds':len(results),'individual_removal_certificates':count,'rounds':results,
    'scope':'Direct fixed-original-input clipped-delta removal with frozen survivor decisions; numerical tolerance 1e-12 and both export-rounding errors; not future causal replay or semantic-maliciousness proof.'}
write_once(root/'reports/containment-verification.json',derived_json_bytes(payload))
print('LIVE EXACT CHECKPOINT AND BOUND CERTIFICATES VERIFIED',count,flush=True)
