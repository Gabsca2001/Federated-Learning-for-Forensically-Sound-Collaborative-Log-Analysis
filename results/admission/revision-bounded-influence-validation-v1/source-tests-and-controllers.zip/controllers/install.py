from pathlib import Path
import shutil,json
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.canonical import sha256_file
repo=Path.cwd();out=Path(__file__).parent;lab=repo/'artifacts/revision-bounded-influence-v1';lab.mkdir(exist_ok=True)
assert implementation_sha256()=='9756ea7efd479992a9aecfc45953b476131e1ad9edfa0bfae32032db50839ff7'
shutil.copytree(repo/'src/fl_forensics',lab/'previous-source/fl_forensics',ignore=shutil.ignore_patterns('__pycache__'))
(out/'before.json').write_text(json.dumps({'implementation_sha256':implementation_sha256(),'git_index_sha256':sha256_file(repo/'.git/index')},sort_keys=True)+'\n')
for source,target in [('bounded_aggregation.py','src/fl_forensics/bounded_aggregation.py'),('test_bounded_aggregation.py','tests/test_bounded_aggregation.py')]:
    path=repo/target;assert not path.exists();path.write_bytes((out/source).read_bytes())
print('EXPERIMENTAL CONTAINMENT MODULE INSTALLED')
