from pathlib import Path
import json,hashlib
from common import *
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan
from fl_forensics.round_derivation import implementation_sha256
out=Path(__file__).parent
tasks=[dict(cohort=c,seed=s,attackers=a,mode=m,strategy=v) for c,s,a in
       [('iid',581593,['client02','client07','client13']),('non-iid',591593,['client03','client08','client12'])]
       for m in ('clean','distributed') for v in ('fedavg','envelope','bounded-envelope')]
protocol={'profile':'bounded-influence-prospective-v1','tasks':tasks,'horizon':15,'attack_rounds':list(range(1,11)),
    'purpose':'Ten attack rounds and five unmodified continuations; active trajectories with the same budgets and controlled references, one new seed per cohort.',
    'bounds':{c:sha256_file(lab/f'{c}-bounds.json') for c in ('iid','non-iid')},
    'source':implementation_sha256(),'controller':sha256_file(Path(__file__)),'adapter':sha256_file(out/'common.py'),
    'evaluation':'Every fixed validation endpoint, clean utility, full/component trigger ASR, detection and clipping, actual removal bounds and scoped CPU time. No test use or post-outcome tuning.',
    'promotion':'Require clean macro-F1 loss <=.02 at every fixed paired endpoint, no clean unsupported context/quorum loss, all bound checks pass, and a reduction in worst ASR on a matched attack-effective control plus the separately frozen adaptive search.',
    'sampled_training_replay':'Repeat local trainings at rounds1 and15 per completed trajectory; verify every derived object and fixed-input removal certificate.'}
save(lab/'prospective-protocol-v2-before-training.json',protocol)
results=[];counts={'generation_local_trainings':0,'repeated_local_trainings':0,'rounds':0,'bounded_rounds':0,'client_removal_certificates':0}
for task in tasks:
    name=f"{task['cohort']}-{task['mode']}-{task['strategy']}";case=lab/'prospective-v2'/name;assert not case.exists()
    save(case/'protocol.json',task)
    gen,cal,env,models,rows,correct=context(task['cohort']);policy=ClientEnvelopePolicy(cal,env);verifier=ClientEnvelopePolicy(cal,env)
    cfg=gen.cfg;plan=DistributedBackdoorPlan.model_validate({**cfg['attack_plan'],'seed':task['seed'],
        'client_components':dict(zip(task['attackers'],[[13],[17],[24]],strict=True)),'attack_rounds':list(range(1,11))})
    reference=read(lab/f'{task["cohort"]}-bounds.json');base=gen.initial;rounds=[]
    for n in range(1,16):
        import time
        target=case/'rounds'/f'round-{n:03d}';save(target/'base-model.json',base)
        _,deltas,exports,training=gen.execute(base,task['seed'],n,plan if task['mode']=='distributed' else None);counts['generation_local_trainings']+=15
        if n in (1,15):
            _,_,duplicate,_=gen.execute(base,task['seed'],n,plan if task['mode']=='distributed' else None)
            assert exports==duplicate;counts['repeated_local_trainings']+=15
        for c,e in zip(gen.clients,exports,strict=True):save(target/'updates'/f'{c}.json',e)
        pin=hashlib.sha256(b''.join(derived_json_bytes(e) for e in [base,*exports])).hexdigest()
        decision,risk,args=score(base,deltas,gen,cal,env,models,policy,n,pin)
        assert verifier.step(n,risk,expected_previous_digest=verifier.head,**args)==decision
        save(target/'decision.json',decision)
        excluded=decision['quarantine_current_round'] if task['strategy']!='fedavg' else []
        if not decision['supported'] and task['strategy']!='fedavg':save(target/'failure.json',{'reason':'unsupported context'});break
        start=time.perf_counter()
        aggregate_model,report,certificate=aggregate(base,exports,gen,excluded,task['strategy']=='bounded-envelope',reference)
        elapsed=time.perf_counter()-start
        if aggregate_model is None:save(target/'failure.json',{'reason':'quorum loss'});break
        if report is not None:
            save(target/'bounded-derivation.json',report);save(target/'removal-certificate.json',certificate)
            counts['bounded_rounds']+=1;counts['client_removal_certificates']+=len(certificate['per_client'])
        active=set(task['attackers']) if task['mode']=='distributed' and n<=10 else set()
        clipped=[c for c,r in report['contributions'].items() if any(f<1 for f in r['clipping_factors']) and r['effective_mass']!='0'] if report else []
        row={'round':n,'excluded':excluded,'intercepted':len(set(excluded)&active),'false_current':len(set(excluded)-active),
             'clipped':clipped,'clipped_poisoned':len(set(clipped)&active),'clipped_clean':len(set(clipped)-active),
             'validation':outcomes(aggregate_model,rows,plan,correct,gen.deps),'aggregation_adapter_wall_seconds':elapsed,
             'wall_scope':'aggregation and its verification/certificate only, excluding training and detector scoring; offline CPU, not TPM overhead',
             'original_model_sha256':{c:sha256_file(target/'updates'/f'{c}.json') for c in gen.clients},'training':training}
        save(target/'global-model.json',aggregate_model);save(target/'round.json',row)
        rounds.append(row);counts['rounds']+=1;base=aggregate_model
        print(json.dumps({'case':name,'round':n,'excluded':excluded,'clipped':len(clipped),'ASR':row['validation']['complete_trigger']['asr']}),flush=True)
    gen.close(case);results.append({'task':task,'rounds':rounds,'complete':len(rounds)==15,'manifest_sha256':sha256_file(case/'manifest.json')})
save(lab/'prospective-results.json',{'counts':counts,'cases':results})
(out/'prospective-results.json').write_bytes((lab/'prospective-results.json').read_bytes())
print('CONTAINMENT PROSPECTIVE COMPLETE',json.dumps(counts),flush=True)
