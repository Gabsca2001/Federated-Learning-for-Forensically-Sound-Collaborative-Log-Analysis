"""Close completed containment experiments, versions, proof annex and live evidence."""
from pathlib import Path
import copy,json,shutil,zipfile
import xml.etree.ElementTree as ET
import numpy as np
from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.crypto import SoftwareECDSASigner,load_public_key,verify_digest_signature
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.storage import write_once

repo=Path.cwd();out=Path(__file__).parent
lab=repo/'artifacts/revision-bounded-influence-v1';live=repo/'artifacts/revision-live-bounded-tpm-v2';tamper=repo/'artifacts/revision-live-bounded-tamper-v1'
dest=repo/'results/revision-bounded-influence-validation-v1';dest.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);write_once(p,derived_json_bytes(v))
def md(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(v)
assert implementation_sha256()=='4b58e1590179dbaa37c8e9760b94bd57549db6c3a228e95f00ee2def26012bbb'
suite=ET.parse(out/'final-full-tests.xml').getroot().find('testsuite')
assert int(suite.attrib['tests'])==678 and suite.attrib['failures']==suite.attrib['errors']=='0'
assert 'LIVE ENVELOPE TPM CASE COMPLETED' in (out/'live-v2.log').read_text()
for branch in ('clean','control','active'):assert read(live/'reports'/f'{branch}-campaign-verification.json')['status']=='verified'
assert read(tamper/'summary.json')['unmodified_copy_verified']
assert len(read(tamper/'summary.json')['cases'])==7
assert all(c['status']!='verified' for c in read(tamper/'summary.json')['cases'])
assert read(lab/'adaptive-query-verification.json')['queries_repeated']==240
pros=read(lab/'prospective-results.json');ad=read(lab/'adaptive-v3/results.json');weak=read(lab/'adaptive-v2/results.json')
assert all(c['complete'] for c in pros['cases']) and all(c['complete'] for c in ad['cases'])
def peak(c):return max(r['validation']['complete_trigger']['asr'] for r in c['rounds'])
def component(c):return max(v['asr'] for r in c['rounds'] for v in r['validation']['component_triggers'].values())
def f1(r):return r['validation']['clean']['macro_f1_all_model_classes']
def utility(cases,cohort=None):
    a=next(c for c in cases if c['task']['mode']=='clean' and c['task']['strategy']=='envelope' and (cohort is None or c['task']['cohort']==cohort))
    b=next(c for c in cases if c['task']['mode']=='clean' and c['task']['strategy']=='bounded-envelope' and (cohort is None or c['task']['cohort']==cohort))
    return max(f1(x)-f1(y) for x,y in zip(a['rounds'],b['rounds'],strict=True))
losses={c:utility(pros['cases'],c) for c in ('iid','non-iid')};losses['adaptive-known-seed-clean']=utility(ad['cases'])
assert all(v<=.02 for v in losses.values())
old=next(c for c in ad['cases'] if c['task']=={'strategy':'envelope','mode':'adaptive'})
bounded=next(c for c in ad['cases'] if c['task']=={'strategy':'bounded-envelope','mode':'adaptive'})
assert peak(old)>0 and peak(bounded)<peak(old) and component(bounded)<component(old)
def distance(strategy):
    base=lab/'adaptive-v3'
    models=[read(base/f'{strategy}-{mode}'/'rounds/round-006/global-model.json') for mode in ('clean','adaptive')]
    a,b=[arrays_from_export(m,np=np) for m in models]
    return float(np.linalg.norm(np.concatenate([(x.astype(float)-y.astype(float)).ravel() for x,y in zip(a,b,strict=True)])))
livecert=read(live/'reports/containment-verification.json')
for name,p in {'live-fixed-endpoints.json':live/'reports/fixed-endpoint-evaluation.json',
    'live-bound-certificates.json':live/'reports/containment-verification.json',
    'live-tamper-summary.json':tamper/'summary.json','live-runtime-image.json':live/'runtime-image.json'}.items():shutil.copyfile(p,out/name)
liveeval=read(out/'live-fixed-endpoints.json')
timings={s:[r['aggregation_adapter_wall_seconds'] for c in pros['cases'] if c['task']['strategy']==s for r in c['rounds']] for s in ('fedavg','envelope','bounded-envelope')}
summary={'profile':'bounded-influence-validation-summary-v1','date':'2026-11-04','implementation_sha256':implementation_sha256(),
    'source_files':len(list((repo/'src/fl_forensics').glob('*.py'))),'tests':{k:suite.attrib[k] for k in ('tests','failures','errors','skipped','time')},
    'prospective':pros['counts'],'worst_clean_macro_F1_losses':losses,
    'adaptive_v3':{'generation_local_trainings':ad['counts']['generation_trainings'],'repeated_local_trainings':ad['counts']['repeated_trainings'],
        'control_peak_full_ASR':peak(old),'bounded_peak_full_ASR':peak(bounded),'bounded_peak_component_ASR':component(bounded),
        'control_final_full_ASR':old['rounds'][-1]['validation']['complete_trigger']['asr'],
        'bounded_final_full_ASR':bounded['rounds'][-1]['validation']['complete_trigger']['asr'],
        'bounded_final_clean_macro_F1':f1(bounded['rounds'][-1]),'control_final_clean_macro_F1':f1(old['rounds'][-1]),
        'final_parameter_L2_from_matched_clean':{s:distance(s) for s in ('envelope','bounded-envelope')},
        'adaptive_status':'Exploratory known-seed replication after strengthening the initial weak attack tie-break; defender references and limits unchanged.'},
    'all_adaptive_queries_replayed':240,'selected_adaptive_aggregates_replayed':48,
    'initial_adaptive_v2_retained':True,'initial_adaptive_v2_counts':weak['counts'],
    'live':{'fresh_verified_swtpm_quotes':225,'local_trainings':225,'trajectories':3,'rounds_each':5,
        'bounded_rounds_exactly_reconstructed':livecert['bounded_rounds'],'fixed_input_removal_certificates':livecert['individual_removal_certificates'],
        'tamper_cases_rejected':7,'evaluation_totals':liveeval['totals'],
        'role':'Known-seed runtime mechanism case, distinct from the offline adaptive experiment; both attacked live controls have full-trigger ASR zero.'},
    'historical_signed_input_derivations':{'original_swtpm_bundles_verified':75,'new_quotes':0,'not_a_replacement_live_trajectory':True},
    'scoped_wall_time_ms':{s:{'median':float(np.median(v)*1000),'p95':float(np.quantile(v,.95)*1000)} for s,v in timings.items()},
    'criteria':{'predeclared_clean_utility_budget_passed':True,'fixed_input_bounds_passed':True,'observed_adaptive_ASR_reduced':True,
        'experimental_live_profile_validated':True,'universal_ASR_or_semantic_security_proved':False,'default_runtime_policy_changed':False,
        'clean_state_recovery_proved':False,'new_test_split_evaluation':False,'ToN_IoT_used':False,'thesis_changed':False}}
save(out/'SUMMARY.json',summary)
table=[]
for c in pros['cases']:
    t=c['task'];table.append(f"| {t['cohort']} | {t['mode']} | {t['strategy']} | {100*peak(c):.4f}% | {100*component(c):.4f}% | {f1(c['rounds'][-1]):.6f} |")
report=f'''# Bounded influence: implementation, validation and live integration

The experimental containment profile is implemented and passes its declared
finite checks. It limits each admitted model delta per tensor, retains the
original signed object, and authenticates the separate transformation. It does
not identify malicious intent or establish universal backdoor resistance.

## Versioned implementation

Final package: {summary['source_files']} files, `{implementation_sha256()}`.
**678 tests pass**, with two existing Typer warnings. The offline-only package
and first live trial sources are separately retained. The default runtime
configuration is not changed. The new profile is explicitly
`live-client-envelope-bounded-v1`, and checkpoints use
`BoundedDelta-FedAvg-observable-envelope`. The complete authenticated prefix,
frozen assets, original submissions and client receipts are required to verify
it. Missing/unsupported observations keep the existing fail-closed behavior.

`bounded_aggregation.py` creates/reconstructs float64 derived deltas and actual
masses. `live_bounded_aggregation.py` binds the declared limits, materializes
the derived object, and supplies the identical numerical backend for checkpoint
creation and verification. The graph inserts `bounded_update_derivation` between
the original bundle and checkpoint, with explicit base/limit dependencies.
The normalized mass coefficient applies to the derived contribution; raw-input
algebraic coefficients are tensor-specific. See
[the conditional proof](BOUNDED_INFLUENCE_PROOF.md) for hypotheses, rounding and
the distinction from causal/semantic claims. Legacy raw-update counterfactual
aggregation explicitly rejects the new profile instead of silently averaging
the originals; clipped-delta removal is a separate operation.

## Frozen clean calibration

Each cohort reuses **3,675 unmodified reference updates**, including responses
to generic perturbed shared states. One common limit per tensor is the fixed
99th percentile, using the `higher` quantile method. Source observable hashes
are checked, and no adversarial-client identities or attack outcomes enter the
fit. These are reused historical clean references on the same dataset, not a
new independent dataset. A clean trajectory means unmodified local training;
its supervised traffic dataset still contains the original network classes.

## Twelve new active trajectories

IID seed 581593 and non-IID seed 591593 each run clean/DBA training under
FedAvg, the original envelope head, and envelope plus containment. All fifteen
rounds use ten attack rounds followed by five unmodified continuations. Each
strategy generates its own future base; this is not frozen-update efficacy.
There is one new seed per cohort. Every fixed validation endpoint is evaluated;
the test split is not used and no clipping threshold is tuned after outcomes.

| Cohort | Training | Strategy | Peak full-trigger ASR | Peak component ASR | Final clean macro-F1 |
|---|---|---|---:|---:|---:|
{chr(10).join(table)}

The new trajectories execute **2,700 local trainings**. Another **360 local
trainings** at predeclared first/last rounds match exactly. All 180 decisions and
aggregates are replayed. The 60 bounded rounds additionally yield **854 direct
individual-removal certificates**, including the two checkpoint export-rounding
allowances and 1e-12 numerical comparison allowance.

The maximum paired clean macro-F1 loss is **{100*losses['iid']:.4f} percentage
points IID** and **{100*losses['non-iid']:.4f} points non-IID**, within the frozen
two-point budget. Clipping an unmodified update is not a malicious-client
classification; utility loss and clipping frequency are reported separately.
In these ordinary cases the original head already attains zero full-trigger
ASR, so the clipping increment has no demonstrated full-trigger ASR advantage
over that head there. The FedAvg controls demonstrate that the attack is
effective in the declared longer ordinary protocol.

## Clipping-aware adaptive replication

The adversary knows the head and clipping limits, trains poisoned and unmodified
endpoints from the actual current base, and evaluates ten fixed candidates per
round against the actual defended aggregate. Seed 551593 is a previously known
case, explicitly a mechanistic replication. Private rows and adversarial-client
identities are used by the controlled generator/evaluator, not the detector.
This offline post-training interpolation/extrapolation does not claim an
undetected TPM training-contract bypass or physically realizable network logs.
The feature-space trigger still uses the declared standardized values.

The first greedy search chose zero manipulation in early ASR ties and remained
ineffective. That result is retained. An explicitly exploratory stronger search
breaks ties in favor of larger allowed manipulation, with unchanged defender
limits. Both defended strategies are rerun under that same stronger objective
and candidate budget. This attack-design follow-up is not held-out certification.

The strengthened unbounded-head control reaches **{100*peak(old):.4f}% peak
full-trigger ASR**, versus **{100*peak(bounded):.4f}%** with containment through
the six fixed rounds. Final unbounded-head ASR is
**{100*old['rounds'][-1]['validation']['complete_trigger']['asr']:.4f}%**.
The bounded model's final clean macro-F1 is **{f1(bounded['rounds'][-1]):.6f}**;
this result is not explained by a general collapse of clean prediction utility.

There are important residuals: the bounded peak **component-trigger ASR is
{100*component(bounded):.4f}%**, and its final parameter L2 distance from matched
clean is **{distance('bounded-envelope'):.9f}** (unbounded-head distance
{distance('envelope'):.9f}). Full-trigger ASR zero does not establish complete
removal of poisoning effects, all-trigger security or recovery of clean state.
The bound is on direct numerical influence at a fixed base; later causal
effects still require genuine subsequent training and an explicit comparison.

Across both adaptive search versions, **240 candidate queries and 48 selected
aggregates** are independently replayed from retained original endpoints,
including nonselected candidate ASRs. Each version executes 540 local trainings
and repeats all 540 exactly. Candidate choices are head-dependent, so this is
an active algorithm/attack-budget comparison, not a paired fixed-update test.

## Signed origins and fresh swtpm validation

Before live integration, 75 retained genuine swtpm bundle signatures and
enrollment signatures were checked against their original commitments. Separate
bounded derivations were produced; no original bundle or historical checkpoint
was rewritten or re-signed, and no new Quote is claimed for that post-hoc check.

The final live case has **225 fresh verified swtpm Quotes and 225 local
trainings** across three separate five-round trajectories: clean containment,
DBA under the original enforced head, and DBA under the bounded head. This is
a known-seed runtime replication with three attack rounds and two continuations,
not one fifteen-round chain or a held-out efficacy campaign. The runtime's
configured quorum is 10; the offline pilot's quorum is 8. All rounds and all
three final campaigns verify. Successors really train from their own preceding
checkpoint, and original client signatures continue to bind those bases.

The 10 bounded live rounds reconstruct **exact original-to-report-to-exported
checkpoint bytes**, and **{livecert['individual_removal_certificates']} direct
individual-removal certificates** pass. Seven mutations on disposable copies
are rejected: clipping factor, original-update reference, current audit result,
predecessor history, client signature, signed mass and predecessor checkpoint.
The unmodified copy verifies. Both attacked live controls have zero full-trigger
ASR in this short case; no live ASR mitigation advantage is inferred from it.
The numerical containment improvement comes from the separate offline adaptive
experiment. Only selected components are measured by the declared swtpm profile;
physical TPM, entire-host trust and semantic data correctness are not claimed.

## Cost, incidents and reproducibility

Measured adapter wall times are retained per round. They include aggregation,
its reconstruction and removal certificates, excluding local training and head
scoring. They were collected under shared computational load, so they are not
isolated microbenchmarks or a paired speedup claim across different active bases.
Median/p95 milliseconds: `{json.dumps(summary['scoped_wall_time_ms'],sort_keys=True)}`.
Live context-to-checkpoint wall times have their own broader declared scope.

The first two controllers stopped before scoring due to a missing serialization
import, after 60 combined local training/replay calls; partial outputs and
controllers are retained. A historical signature-check helper then corrected
the enrollment field access before deriving any output. The initial live trial
is retained separately: numerical string indices could sort lexically rather
than in input order with over ten clients. The final backend zero-pads those
indices and enforces exact report/runtime array agreement before creating a
checkpoint; five multi-input regressions cover this. Its source and fresh TPM
evidence were regenerated. An external certificate helper initially assumed
quorum 8 and was corrected to read 10 from the signed live contract. No model
or result is changed by that reporting correction.

Clipping is an established component, already present in the reproduced
literature baseline. This is not claimed as a novel defense or a new SOTA
comparison. The thesis contribution concerns authenticated transformations,
explicit influence assumptions and reproducible quantitative diagnosis.
The 119-file final source, predecessor source releases, controllers, exact
frozen image, public artifact closures and local analyst-signed completion are
retained. Private keys/TPM private state are excluded from public closures.
The signature is local integrity, not independent witness time or certification.
Receipt completeness remains relative to supplied client evidence; trusted
deadline/delivery and an independent append-only witness are not added.
The ToN-IoT work and the actual thesis remain deferred in this implementation
step. See [SUMMARY.json](SUMMARY.json) and [THESIS_HANDOFF.md](THESIS_HANDOFF.md).
'''
md(out/'REPORT.md',report)
md(out/'THESIS_HANDOFF.md',f'''# Thesis handoff — containment profile

The new text must describe an experimental containment contract rather than
reliable semantic client exclusion. Original signatures cover the submitted
models; separately authenticated derived objects record clipping. The normalized
mass is applied to transformed deltas; tensor-specific raw coefficients and
base coefficients must be distinguished. Use the conditional proof annex and
keep survivor quorum, fixed decisions, final export rounding and future
retraining hypotheses explicit. Do not silently substitute coefficients in the
original Delta/J definitions.

Suggested result statement: In the exploratory known-seed white-box replication,
the unbounded head reaches 100% peak full-trigger validation ASR, whereas the
bounded variant remains at zero over six fixed rounds. Its component-trigger
peak remains {100*component(bounded):.4f}% and its final model differs from matched
clean by L2 {distance('bounded-envelope'):.9f}; complete decontamination is not
demonstrated. The clean utility budget passes in the two fresh-seed ordinary
cohorts. These are same-dataset validation results, not independent-dataset or
universal adaptive-security evidence. The stronger attack was developed after
the initial tie-break selected no manipulation; that history must be disclosed.

The new swtpm case validates authentic originals, separate transformations,
exact checkpoint reconstruction and 145 direct removal certificates. Its short
attack control also has ASR zero, so it supplies mechanism evidence rather than
a live efficacy advantage. Clipping is not presented as a novel defense or
superiority over FLAME/WeiDetect/FedGradTrace. Group-intent inference remains
the separately qualified retrospective analysis agreed with the supervisor.

AI-assistance disclosure must accurately include assisted implementation,
experiment controllers, debugging, validation reports and proof drafts. These
artifacts document the assistance; they do not establish a percentage of AI
authorship or replace the student's review and responsibility. The actual thesis
source has not been edited by this step.
''')
# Preserve the exact previous maintained-document versions before appending.
names=('STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md','FORMAL_PROFILE_CORRESPONDENCE.md')
for name in names:
    p=repo/'docs'/name;target=out/'previous-documents'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
    with p.open('a') as stream:stream.write('\n\n## Bounded influence profile — 4 November 2026\n\nAn explicit experimental per-tensor containment profile now preserves authenticated originals and derived deltas separately, with final-source tests, a conditional influence proof and a fresh swtpm mechanism case. Full-trigger ASR is reduced in the specified offline adaptive replication; component-trigger residuals and model-state differences remain. This does not validate semantic client exclusion or universal decontamination. The original raw-update counterfactual profile remains versioned; the bounded profile uses its explicit clipped-delta operation. Details: [BOUNDED_INFLUENCE_VALIDATION.md](BOUNDED_INFLUENCE_VALIDATION.md).\n')
md(repo/'docs/BOUNDED_INFLUENCE_VALIDATION.md',report.replace('](BOUNDED_INFLUENCE_PROOF.md)','](BOUNDED_INFLUENCE_THEOREMS.md)').replace('](SUMMARY.json)','](../results/revision-bounded-influence-validation-v1/SUMMARY.json)').replace('](THESIS_HANDOFF.md)','](../results/revision-bounded-influence-validation-v1/THESIS_HANDOFF.md)'))
shutil.copyfile(out/'BOUNDED_INFLUENCE_PROOF.md',repo/'docs/BOUNDED_INFLUENCE_THEOREMS.md')
source=repo/'src/fl_forensics';snapshot=live/'final-source/fl_forensics';shutil.copytree(source,snapshot,ignore=shutil.ignore_patterns('__pycache__'))
with zipfile.ZipFile(out/'source-tests-and-controllers.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for folder,prefix in ((source,'final-source/fl_forensics'),(lab/'previous-source/fl_forensics','parent-source/fl_forensics'),(lab/'offline-source/fl_forensics','offline-source/fl_forensics'),(repo/'artifacts/revision-live-bounded-tpm-v1/source-release/fl_forensics','first-live-source/fl_forensics')):
        for p in sorted(folder.glob('*.py')):z.write(p,prefix+'/'+p.name)
    for p in out.glob('*.py'):z.write(p,'controllers/'+p.name)
    for p in (out/'attempt-001-source').glob('*.py'):z.write(p,'attempt-001-controllers/'+p.name)
    for name in ('test_bounded_aggregation.py','test_live_bounded_aggregation.py'):z.write(repo/'tests'/name,'tests/'+name)
    for p in (out/'previous-documents').glob('*.md'):z.write(p,'previous-documents/'+p.name)
    for name in ('BOUNDED_INFLUENCE_VALIDATION.md','BOUNDED_INFLUENCE_THEOREMS.md',*names):z.write(repo/'docs'/name,'docs/'+name)
    for p in (repo/'scripts').glob('revision_live_bounded*.py'):z.write(p,'scripts/'+p.name)
    z.write(repo/'configs/revision-bounded-live-trust.yaml','configs/revision-bounded-live-trust.yaml')
    z.write(repo/'Dockerfile.revision-live-bounded','Dockerfile.revision-live-bounded')
with zipfile.ZipFile(out/'source-tests-and-controllers.zip') as z:assert z.testzip() is None
roots={}
for root in (lab,live,tamper):
    files={}
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if not p.is_file() or p.is_symlink() or '__pycache__' in rel.parts or 'tpm-state' in rel.parts or p.name=='public-closure.json':continue
        if p.suffix=='.ctx' or any('private' in part.lower() for part in rel.parts):continue
        files[rel.as_posix()]=sha256_file(p)
    save(root/'public-closure.json',{'profile':'bounded-influence-public-artifact-closure-v1','files':files,
        'excluded':'Private keys, TPM private state and runtime contexts; original private evidence remains local.'})
    roots[str(root)]=sha256_file(root/'public-closure.json')
    save(out/(root.name+'-closure.json'),{'root':str(root),'closure_sha256':roots[str(root)]})
before=read(out/'before.json');assert sha256_file(repo/'.git/index')==before['git_index_sha256']
thesis=read(out.parent/'formal-closure-20261103/before-review.json')
assert all(sha256_file(Path(thesis['thesis_root'])/n)==h for n,h in thesis['thesis_sources'].items())
signer=SoftwareECDSASigner.generate();write_once(repo/'artifacts/revision-bounded-influence-authority-v1/analyst.private.pem',signer.private_pem());write_once(out/'analyst.public.pem',signer.public_pem())
core={'profile':'bounded-influence-analyst-completion-v1','date':'2026-11-04',
    'parent_completion_sha256':'56da319c11603d5d56ef29c8bd3e420dee03313da119c7326b6622b54c8d0cac',
    'implementation_sha256':implementation_sha256(),'summary':summary,'artifact_roots':roots,
    'maintained_documents':{name:sha256_file(repo/'docs'/name) for name in (*names,'BOUNDED_INFLUENCE_VALIDATION.md','BOUNDED_INFLUENCE_THEOREMS.md')},
    'artifacts':{p.relative_to(out).as_posix():sha256_file(p) for p in sorted(out.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ('completion.json','completion.sha256')},
    'authority_role':'Local software analyst; not independent time, witness, physical TPM or external scientific certification'}
d=sha256_bytes(derived_json_bytes(core));signature=signer.sign_digest(d)
save(out/'completion.json',{'core':core,'core_digest':d,'signature':{'key_id':signer.key_id,'value_b64':signature}})
assert verify_digest_signature(load_public_key(signer.public_pem()),d,signature)
assert all(sha256_file(out/n)==h for n,h in core['artifacts'].items())
write_once(out/'completion.sha256',(sha256_file(out/'completion.json')+'\n').encode())
for p in out.iterdir():
    if p.is_file() and p.suffix in ('.md','.json','.xml','.zip','.log','.pem','.sha256'):shutil.copyfile(p,dest/p.name)
shutil.copyfile(out/'REPORT.md',dest/'README.md')
print('CONTAINMENT VALIDATION SEALED',sha256_file(out/'completion.json'),flush=True)
