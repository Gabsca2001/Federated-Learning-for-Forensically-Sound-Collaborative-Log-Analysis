from pathlib import Path
import re
p=Path('tests/test_live_bounded_aggregation.py');s=p.read_text()
s,n=re.subn(r'from test_live_envelope import \([\s\S]*?\)\n','import test_live_envelope as envelope_fixtures\nfrom test_live_envelope import put\n',s,count=1)
assert n==1
s=s.replace('def bounded(fixture):','def bounded(tmp_path, monkeypatch):\n    fixture = envelope_fixtures.fixture.__wrapped__(tmp_path, monkeypatch)')
p.write_text(s)
