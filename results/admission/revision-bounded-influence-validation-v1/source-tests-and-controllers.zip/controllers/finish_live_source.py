from pathlib import Path
repo=Path.cwd();out=Path(__file__).parent
p=repo/'src/fl_forensics/live_envelope.py';s=p.read_text()
old='"profile": PROFILE,'
assert s.count(old)==1;s=s.replace(old,'"profile": value["profile"],');p.write_text(s)
p=repo/'tests/test_live_bounded_aggregation.py';assert not p.exists();p.write_bytes((out/p.name).read_bytes())
print('LIVE PROFILE TESTS INSTALLED')
