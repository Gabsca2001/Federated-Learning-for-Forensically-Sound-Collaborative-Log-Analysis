"""Keep partial runs and correct a controller-only missing import."""
from pathlib import Path
import json,shutil
repo=Path.cwd();out=Path(__file__).parent;lab=(repo/'artifacts/revision-bounded-influence-v1').resolve()
before=out/'attempt-001-source';before.mkdir()
for name in ('common.py','prospective.py','adaptive.py'):shutil.copyfile(out/name,before/name)
path=out/'common.py';text=path.read_text();assert 'from fl_forensics.preprocessing import derived_json_bytes' not in text
path.write_text(text+'\nfrom fl_forensics.preprocessing import derived_json_bytes\n')
for name,newname in [('prospective.py','prospective_v2.py'),('adaptive.py','adaptive_v2.py')]:
    text=(out/name).read_text()
    if name=='prospective.py':
        text=text.replace("lab/'prospective'","lab/'prospective-v2'").replace('prospective-protocol-before-training.json','prospective-protocol-v2-before-training.json')
    else:text=text.replace("lab/'adaptive'","lab/'adaptive-v2'")
    (out/newname).write_text(text)
(out/'controller-recovery.json').write_text(json.dumps({'incident':'Missing derived_json_bytes import in the experiment controller. Both runs stopped after their first unmodified local endpoints and repeat, before scoring or aggregation.',
    'partial_local_training_calls':60,'package_changed':False,'calibration_changed':False,
    'action':'Old controllers and partial runs retained; corrected controllers run in new prospective-v2 and adaptive-v2 directories under the same reserved task specification.'},sort_keys=True,indent=2)+'\n')
print('Controller recovery prepared; partial artifacts preserved')
