from pathlib import Path
import json,shutil
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.canonical import sha256_file
repo=Path.cwd();out=Path(__file__).parent;old=repo/'artifacts/revision-live-bounded-tpm-v1';lab=repo/'artifacts/revision-live-bounded-tpm-v2'
assert not lab.exists();lab.mkdir()
for name in ('partition','config'):shutil.copytree(old/name,lab/name)
shutil.copyfile(old/'initial-model.json',lab/'initial-model.json')
script=(repo/'scripts/revision_live_bounded.py').read_text()
script=script.replace('revision_live_bounded.py','revision_live_bounded_v2.py').replace('revision-live-bounded:20261104-v1','revision-live-bounded:20261104-v2').replace('revision-bounded-tpm-20261104-v1-','revision-bounded-tpm-20261104-v2-')
runner=repo/'scripts/revision_live_bounded_v2.py';assert not runner.exists();runner.write_text(script)
protocol=json.loads((old/'reserved-protocol-before-training.json').read_bytes())
protocol.update(profile='live-bounded-integration-v2',source_implementation_sha256=implementation_sha256(),implementation_sha256=implementation_sha256(),runner_sha256=sha256_file(runner),
    refinement='Numeric input indices are zero-padded. The derived report and actual runtime pre-export aggregates must match bit-for-bit before a checkpoint is created. Previous live-v1 partial evidence is retained, with no validity relabeling.')
(lab/'reserved-protocol-before-training.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
(out/'live-protocol-v2.json').write_bytes((lab/'reserved-protocol-before-training.json').read_bytes())
note={'before_source_sha256':json.loads((old/'reserved-protocol-before-training.json').read_bytes())['implementation_sha256'],
    'reason':'Stringified numerical indices sorted lexically, differing from numeric/client order with more than ten clients. This could change float64 accumulation and the pre-export digest.',
    'correction':'Zero-pad numerical keys and enforce bitwise report/runtime aggregate agreement before checkpoint creation.',
    'old_trial_preserved':True,'old_trial_is_not_the_final_live_evidence':True}
(out/'live-order-refinement.json').write_text(json.dumps(note,sort_keys=True,indent=2)+'\n')
test=repo/'tests/test_live_bounded_aggregation.py'
with test.open('a') as s:s.write('''\n\n@pytest.mark.parametrize("seed", [0,1,3,7,8])
def test_more_than_ten_inputs_share_report_and_runtime_order(bounded, seed):
    from fl_forensics.bounded_aggregation import aggregate_bounded, digest
    rng=np.random.default_rng(seed)
    values=[np.array([v]) for v in rng.normal(size=15)]
    entries=[([a],float(i+1)) for i,a in enumerate(values)]
    actual=backend(bounded.workspace,None)(entries)
    names=[f"client{i:02d}" for i in range(15)]
    expected,_=aggregate_bounded([[0.]],{c:[a] for c,a in zip(names,values,strict=True)},
        masses={c:i+1 for i,c in enumerate(names)},mandatory_gates=dict.fromkeys(names,True),
        limits=[.1],reference_digest="a"*64,minimum_contributors=1)
    assert all(np.array_equal(a,b) for a,b in zip(actual,expected,strict=True))
''')
print('FINAL LIVE SOURCE AND PROTOCOL',implementation_sha256(),flush=True)
