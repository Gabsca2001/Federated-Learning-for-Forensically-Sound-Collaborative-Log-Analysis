"""Preserve the first live trial and enforce one exact accumulation order."""
from pathlib import Path
import os,signal,shutil,json,time
from fl_forensics.round_derivation import implementation_sha256
repo=Path.cwd();out=Path(__file__).parent;old=repo/'artifacts/revision-live-bounded-tpm-v1'
# Interrupt only the matching host orchestrator; its finally block stops its own TPMs.
matches=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:args=(p/'cmdline').read_bytes().split(b'\0')
    except (OSError,PermissionError):continue
    if b'scripts/revision_live_bounded.py' in args and b'--workspace' in args and b'artifacts/revision-live-bounded-tpm-v1' in args:matches.append(int(p.name))
assert len(matches)<=1,matches
for pid in matches:os.kill(pid,signal.SIGINT)
snapshot=old/'source-release/fl_forensics';assert not snapshot.exists()
shutil.copytree(repo/'src/fl_forensics',snapshot,ignore=shutil.ignore_patterns('__pycache__'))
p=repo/'src/fl_forensics/live_bounded_aggregation.py';s=p.read_text()
assert s.count('str(i)')==2
s=s.replace('str(i)','f"{i:06d}"')
needle='    if parameters is None:\n        raise ValueError("bounded derivation lacks quorum")'
assert needle in s
s=s.replace(needle,needle+'\n    ordered = [(models[c], float(masses[c])) for c in sorted(models) if Decimal(masses[c]) > 0]\n    runtime = backend(workspace, None)(ordered)\n    if not all(np.array_equal(a,b) for a,b in zip(parameters,runtime,strict=True)):\n        raise ValueError("bounded report and runtime accumulation order disagree")')
p.write_text(s)
(out/'live-order-refinement.json').write_text(json.dumps({'before_source_sha256':implementation_sha256(snapshot),
    'reason':'The generic numerical backend used stringified indices, whose lexical order differs from numeric/client order with more than ten clients. Both paths must use the same exact float64 accumulation order.',
    'correction':'Zero-pad numerical input keys and explicitly assert bitwise equality of the report aggregate and runtime backend before checkpoint creation.',
    'v1_trial_interrupted_for_implementation_refinement':True,'original_v1_evidence_preserved':True},sort_keys=True,indent=2)+'\n')
print('Live order refined; previous source and evidence preserved')
