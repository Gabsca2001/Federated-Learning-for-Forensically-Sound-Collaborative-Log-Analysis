from pathlib import Path
import json,shutil,yaml
from fl_forensics.canonical import sha256_file
from fl_forensics.round_derivation import implementation_sha256
repo=Path.cwd();out=Path(__file__).parent
lab=repo/'artifacts/revision-live-bounded-tpm-v1';assert not lab.exists();lab.mkdir()
old=repo/'artifacts/revision-live-envelope-tpm-v2'
for name in ('partition','config'):shutil.copytree(old/name,lab/name)
shutil.copyfile(old/'initial-model.json',lab/'initial-model.json')
shutil.copyfile(repo/'artifacts/revision-bounded-influence-v1/non-iid-bounds.json',lab/'config/observable-assets/bounds.json')
cfg=yaml.safe_load((lab/'config/federation.yaml').read_text());cfg['training']['seed']=591593
(lab/'config/federation.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
plan=json.loads((lab/'config/dba-plan.json').read_bytes());plan['plan']['seed']=591593
plan['plan']['client_components']={'client03':[13],'client08':[17],'client12':[24]}
(lab/'config/dba-plan.json').write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n')
original=yaml.safe_load((lab/'config/enforce.yaml').read_text())
for branch in ('clean','control','active'):
    config=json.loads(json.dumps(original))
    config['runtime_admission']['policy_id']='live-bounded-'+branch+'-v1'
    if branch!='control':
        value=config['runtime_admission']['observable_policy'];value['profile']='live-client-envelope-bounded-v1'
        value['assets']['bounds.json']=sha256_file(lab/'config/observable-assets/bounds.json')
    (lab/'config'/f'{branch}.yaml').write_text(yaml.safe_dump(config,sort_keys=False))
trust=yaml.safe_load((repo/'configs/revision-envelope-live-trust-v2.yaml').read_text())
trust['attestation']['baseline_id']='bounded-live-tpm-20261104-v1'
for component,path in [('bounded-aggregation','src/fl_forensics/bounded_aggregation.py'),('bounded-live-adapter','src/fl_forensics/live_bounded_aggregation.py')]:
    trust['measurements'].append({'component_id':component,'component_version':'1.0.0','pcr_index':7,'path':path})
trustpath=repo/'configs/revision-bounded-live-trust.yaml';assert not trustpath.exists()
trustpath.write_text(yaml.safe_dump(trust,sort_keys=False))
script=(repo/'scripts/revision_live_envelope_v2.py').read_text()
script=script.replace("BRANCHES = ('clean','shadow','active')","BRANCHES = ('clean','control','active')")
script=script.replace('revision-envelope-live-trust-v2.yaml','revision-bounded-live-trust.yaml')
script=script.replace("root/'config'/('audit_only.yaml' if branch=='shadow' else 'enforce.yaml')","root/'config'/f'{branch}.yaml'")
script=script.replace('revision_live_envelope_v2.py','revision_live_bounded.py')
script=script.replace('revision-envelope-tpm-20261103-v2-','revision-bounded-tpm-20261104-v1-')
script=script.replace('live-envelope-','live-bounded-').replace('20261103-v1','20261104-v1')
script=script.replace('revision-live-envelope:20261103-v2','revision-live-bounded:20261104-v1').replace('revision-live-envelope-tpm-v2','revision-live-bounded-tpm-v1')
runner=repo/'scripts/revision_live_bounded.py';assert not runner.exists();runner.write_text(script)
protocol={'profile':'live-bounded-integration-v1','branches':['clean','control','active'],'rounds':5,
    'source_implementation_sha256':implementation_sha256(),'implementation_sha256':implementation_sha256(),
    'training_seed':591593,'base_model_sha256':sha256_file(lab/'initial-model.json'),'attack_plan':plan,
    'case_role':'Known-seed runtime replication, three attack rounds plus two unmodified continuations. Enforced original head control versus bounded head. Mechanism validation; not a held-out statistical efficacy claim.',
    'branches_semantics':{'clean':'unmodified training with containment','control':'declared DBA with original head, no containment','active':'declared DBA with original head and containment'},
    'bound_reference_sha256':sha256_file(lab/'config/observable-assets/bounds.json'),
    'runner_sha256':sha256_file(runner),'config_files':{p.relative_to(lab).as_posix():sha256_file(p) for p in (lab/'config').rglob('*') if p.is_file()},
    'verification':'Fresh swtpm Quotes and signed originals; original and derived objects distinct, clipping factors and original references in authenticated round graph; complete numerical and campaign verification.'}
(lab/'reserved-protocol-before-training.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
(out/'live-protocol.json').write_bytes((lab/'reserved-protocol-before-training.json').read_bytes())
dockerfile=repo/'Dockerfile.revision-live-bounded'
dockerfile.write_text('FROM revision-attested-chain:20261102-v4\nCOPY src /app/src\nCOPY configs /app/configs\nCOPY scripts /app/scripts\nCOPY Dockerfile.m4 /app/Dockerfile.m4\nCOPY Dockerfile.revision-dba /app/Dockerfile.revision-dba\nENV PYTHONPATH=/app/src:/app/scripts\nENV OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MKL_CBWR=COMPATIBLE\n')
print('LIVE CONTAINMENT PROTOCOL FROZEN',implementation_sha256(),flush=True)
