"""Clean-only norm calibration, frozen before all new experiment training."""
from pathlib import Path
import json,numpy as np
from fl_forensics.canonical import sha256_file
from fl_forensics.round_derivation import implementation_sha256
from revision_dba_experiment import save
repo=Path.cwd();out=Path(__file__).parent;lab=repo/'artifacts/revision-bounded-influence-v1'
inputs=repo/'artifacts/revision-geometry-detector-v1/fit-observables'
binding=json.loads((inputs/'closure.json').read_bytes())
for rel,pin in binding['files'].items():assert sha256_file(inputs/rel)==pin
save(lab/'calibration-protocol-before-fit.json',{'profile':'clean-common-tensor-cap-fit-v1','quantile':.99,'quantile_method':'higher',
     'input_closure_sha256':sha256_file(inputs/'closure.json'),'reference_roles':['normalizer','null'],
     'selection':'One predeclared per-tensor common limit across clients; clean reference normal and generically perturbed states only. No attack-derived fitting or threshold search.',
     'utility_budget':'At every fixed clean validation endpoint, bounded-head macro-F1 must be no more than .02 below the paired original-head endpoint. Any unsupported clean trajectory or quorum loss rejects promotion.',
     'implementation_sha256':implementation_sha256()})
for cohort in ('iid','non-iid'):
    schema=json.loads((inputs/cohort/'schema.json').read_bytes());sizes=schema['sizes'];ends=np.cumsum([0,*sizes]);norms=[];pins={}
    for role in ('normalizer','null'):
        for p in sorted((inputs/cohort/role).glob('*.npz')):
            with np.load(p,allow_pickle=False) as z:changes=z['updates']
            norms.append(np.stack([np.linalg.norm(changes[:,:,a:b],axis=2).ravel() for a,b in zip(ends[:-1],ends[1:],strict=True)],axis=1))
            pins[p.relative_to(inputs).as_posix()]=sha256_file(p)
    values=np.concatenate(norms)
    reference={'profile':'clean-common-tensor-l2-cap-v1','cohort_id':schema['cohort_id'],'sizes':sizes,
        'limits':np.maximum(np.quantile(values,.99,axis=0,method='higher'),1e-12).tolist(),
        'reference_update_count':len(values),'quantile':.99,'method':'higher','input_files':pins,
        'fit_profile':'unmodified training at normal and generic perturbed shared states; historical clean references reused, evaluation seeds are separate'}
    save(lab/f'{cohort}-bounds.json',reference)
    print(json.dumps({'cohort':cohort,'updates':len(values),'limits':reference['limits']}),flush=True)
