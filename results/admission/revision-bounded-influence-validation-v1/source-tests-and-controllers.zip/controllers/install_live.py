from pathlib import Path
import shutil,json
from fl_forensics.round_derivation import implementation_sha256
repo=Path.cwd();out=Path(__file__).parent;lab=repo/'artifacts/revision-bounded-influence-v1'
shutil.copytree(repo/'src/fl_forensics',lab/'offline-source/fl_forensics',ignore=shutil.ignore_patterns('__pycache__'))
(out/'offline-source-version.json').write_text(json.dumps({'implementation_sha256':implementation_sha256()})+'\n')
path=repo/'src/fl_forensics/live_bounded_aggregation.py';assert not path.exists();path.write_bytes((out/path.name).read_bytes())
def edit(name,old,new,count=1):
    p=repo/'src/fl_forensics'/name;text=p.read_text();assert text.count(old)==count,(name,old,text.count(old));p.write_text(text.replace(old,new))
edit('live_envelope.py','value["profile"] != PROFILE','value["profile"] not in (PROFILE, "live-client-envelope-bounded-v1")')
edit('live_envelope.py','    if set(value["assets"]) != set(ASSETS):','    expected_assets = set(ASSETS) | ({"bounds.json"} if value["profile"] == "live-client-envelope-bounded-v1" else set())\n    if set(value["assets"]) != expected_assets:')
edit('live_envelope.py','    for name in ASSETS:', '    for name in value["assets"]:',2)
edit('live_envelope.py','paths = {name: Path(public) / "observable-assets" / name for name in ASSETS}', 'paths = {name: Path(public) / "observable-assets" / name for name in value["assets"]}')
edit('in_round_admission_models.py','"FedAvg-observable-envelope",','"FedAvg-observable-envelope",\n        "BoundedDelta-FedAvg-observable-envelope",')
edit('in_round_admission.py','                "live_envelope.py",','                "live_envelope.py",\n                "bounded_aggregation.py",\n                "live_bounded_aggregation.py",')
edit('in_round_admission.py','    records: list[dict[str, Any]],\n) -> tuple[dict[str, Any], list[InRoundCheckpointInput], Decimal]:',
     '    records: list[dict[str, Any]],\n    aggregate_override: Any = None,\n) -> tuple[dict[str, Any], list[InRoundCheckpointInput], Decimal]:')
edit('in_round_admission.py','    averaged = fedavg(weighted_updates, aggregate=aggregate)','    averaged = fedavg(weighted_updates, aggregate=aggregate_override or aggregate)')
# The same deterministic backend is used in creation, verification and signed backend descriptors.
edit('in_round_admission.py','from .in_round_admission_models import (','from .live_bounded_aggregation import backend as aggregation_backend, label as aggregation_label, materialize as materialize_bounded\nfrom .in_round_admission_models import (')
edit('in_round_admission.py','aggregate=dependencies()[4],','aggregate=aggregation_backend(workspace, dependencies()[4]),',3)
edit('in_round_admission.py','base=base, decisions=decisions, records=records','base=base, decisions=decisions, records=records, aggregate_override=aggregation_backend(workspace, dependencies()[4])',2)
edit('in_round_admission.py','    global_model, inputs, total_weight = _aggregate_inputs(',
     '    materialize_bounded(workspace, records, decisions, True)\n    global_model, inputs, total_weight = _aggregate_inputs(')
edit('in_round_admission.py','        recomputed_model, inputs, total_weight = _aggregate_inputs(',
     '        materialize_bounded(workspace, records, decisions, False)\n        recomputed_model, inputs, total_weight = _aggregate_inputs(')
edit('in_round_admission.py','"FedAvg-" + contract.core.primary_policy.replace("_", "-")','aggregation_label(workspace, contract)',2)
edit('round_derivation.py','    return profile\n','    if hasattr(aggregate, "forensic_profile"):\n        profile.update(aggregate.forensic_profile)\n    return profile\n')
edit('round_derivation.py','    by_id = {item.submission_id: item for item in inventory.core.entries}',
     '    from .live_bounded_aggregation import enabled as bounded_enabled\n    bounded_node = None\n    if checkpoint_hash is not None and bounded_enabled(workspace):\n        bounded_node = node("bounded_update_derivation", sha256_file(workspace / "bounded-update-derivation.json"))\n        limit_node = node("aggregation_limits", sha256_file(workspace / "public/observable-assets/bounds.json"))\n        base_node = node("base_model", context.core.base_model_sha256)\n        edges.update({(base_node,bounded_node,"num"),(limit_node,bounded_node,"num"),(bounded_node,target,"num"),(contract,bounded_node,"dec")})\n    by_id = {item.submission_id: item for item in inventory.core.entries}')
edit('round_derivation.py','edges.update({(bundle, target, "num"), (decision, target, "dec")})',
     'edges.update({(bundle, bounded_node or target, "num"), (decision, target, "dec")})')
edit('round_derivation.py','        elif checkpoint_hash is not None and item.decision_sha256 is not None:\n            edges.add((decision, target, "audit"))',
     '        elif checkpoint_hash is not None and item.decision_sha256 is not None:\n            edges.add((decision, target, "audit"))\n            if bounded_node is not None: edges.add((bundle, bounded_node, "audit"))')
edit('counterfactual_round.py','        baseline = _aggregate(base, ordered, original_masses, contract.core.minimum_contributors)',
     '        from .live_bounded_aggregation import enabled as bounded_enabled\n        if bounded_enabled(round_workspace):\n            raise CounterfactualError("bounded-profile removals require the explicit clipped-delta adapter; legacy raw-update counterfactual aggregation is unsupported")\n        baseline = _aggregate(base, ordered, original_masses, contract.core.minimum_contributors)')
print('LIVE BOUNDED PROFILE INSTALLED')
