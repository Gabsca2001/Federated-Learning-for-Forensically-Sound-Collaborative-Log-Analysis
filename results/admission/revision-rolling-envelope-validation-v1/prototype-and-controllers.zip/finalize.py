"""Seal completed research outputs; never hash an open stdout log."""
from pathlib import Path
import json,shutil,zipfile
import xml.etree.ElementTree as ET
from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.crypto import SoftwareECDSASigner,load_public_key,verify_digest_signature
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.round_derivation import implementation_sha256
from fl_forensics.storage import write_once
repo=Path.cwd();out=Path(__file__).parent
lab=repo/'artifacts/revision-rolling-envelope-v1';ad=repo/'artifacts/revision-rolling-adaptive-pilot-v1'
dest=repo/'results/revision-rolling-envelope-validation-v1';dest.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_bytes())
def save(p,v):write_once(p,derived_json_bytes(v))
def md(p,text):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
assert implementation_sha256()=='9756ea7efd479992a9aecfc45953b476131e1ad9edfa0bfae32032db50839ff7'
assert 'PAIRED PROSPECTIVE CASES COMPLETED' in (out/'prospective.log').read_text()
assert 'local_training_calls_repeated' in (out/'adaptive-verification.log').read_text()
suite=ET.parse(out/'prototype-tests.xml').getroot().find('testsuite');assert suite.attrib['failures']==suite.attrib['errors']=='0'
pros=read(lab/'prospective-results.json');adaptive=read(ad/'summary.json');verification=read(ad/'verification.json')
assert verification['local_training_calls_repeated']==270
for name,path in [('adaptive-results.json',ad/'summary.json'),('adaptive-verification.json',ad/'verification.json')]:
    assert (out/name).read_bytes()==path.read_bytes()
rows=[]
for c in pros['cases']:
    t=c['task'];rows.append(f"| {t['cohort']} | {t['mode']} | {t['head']} | {len(c['rounds'])} | {c['intercepted']} | {c['false_current']} | {100*c['peak_asr']:.4f}% |")
attack=next(a for a in adaptive['arms'] if a['arm']=='adaptive-active-rolling')
peak=max(r['validation']['complete_trigger']['asr'] for r in attack['rounds'])
alphas=[r['alpha'] for r in attack['rounds']]
manipulated=3*sum(a!=0 for a in alphas)
false=sum(c['false_current'] for c in pros['cases'] if c['task']['head']=='rolling-2')
complete=all(c['complete'] for c in pros['cases'])
promote=complete and not false and peak==0
assert not promote,'Unexpected outcome: review promotion criteria manually'
summary={'profile':'rolling-peak-validation-summary-v1','prototype_tests':int(suite.attrib['tests']),
    'maintained_source_unchanged':True,'maintained_implementation_sha256':implementation_sha256(),
    'paired_counts':pros['counts'],'all_paired_trajectories_complete':complete,
    'rolling_currently_clean_exclusions':false,'adaptive_peak_validation_asr':peak,
    'adaptive_final_validation_asr':attack['rounds'][-1]['validation']['complete_trigger']['asr'],
    'adaptive_alphas':alphas,'adaptive_numerically_manipulated_updates':manipulated,
    'adaptive_quarantined_updates':sum(len(r['quarantined']) for r in attack['rounds']),
    'adaptive_generation_local_trainings':270,'adaptive_repeated_local_trainings':270,'adaptive_candidate_queries':60,
    'promoted':False,'new_TPM_campaign':False,'test_split_used':False,'thesis_changed':False}
save(out/'SUMMARY.json',summary)
report=f'''# Rolling peak memory: validation and rejection

The two-round rolling-peak candidate is **not promoted**. It resolves the old
single-peak/constant-weak-excess example, but an attacker that knows the new head
can alternate stronger manipulation and unmodified updates and evade the
two-observation confirmation mechanism. This is an empirical counterexample,
not a statement that no other detector could work.

## Frozen development

The unchanged clean-only predictors and envelopes are reused. Windows 2, 3 and
4 were declared before scoring the 48 already-used development cases. Selection
required zero never-attacker and currently-clean scheduled-attacker exclusions
and no quorum loss, then maximum shadow interceptions and smallest window.
Window 2 scored 474 intercepted poisoned updates versus 452 for the old head,
with zero observed false proposals. This was development, not a held-out result.
No thresholds were refitted on attack identities or outcomes.

## New paired active trajectories

The candidate was frozen before eight fifteen-round trajectories: IID seed
561593, non-IID seed 571593, clean/DBA training, old/rolling active heads.
Attackers are client02/09/14 and client03/08/12 respectively. Attacks occur at
rounds 1–6; rounds 7–15 use unmodified training from the actual evolving model.
This tests delayed exclusion of clean responses to contaminated bases. There is
one new seed per cohort, on the same dataset, with no independent-dataset claim.
Both heads generate their own successors, not frozen-update approximations.

| Cohort | Training | Head | Completed rounds | Intercepted poisoned updates | Currently clean exclusions | Peak full-trigger validation ASR |
|---|---|---|---:|---:|---:|---:|
{chr(10).join(rows)}

Counters: {json.dumps(pros['counts'],sort_keys=True)}. Local training at rounds
1 and 15 of each completed trajectory is repeated exactly. Every retained
decision and aggregate is replayed. This deterministic verification is not a
mathematical proof of semantic correctness or an independent implementation.
All fixed endpoints include clean utility and complete/component triggers;
the test split is not accessed. Quarantine counts refer to current manipulated
updates; unmodified updates can still inherit effects through their shared base.

## White-box adaptive replication

The previously known non-IID seed 551593 case is deliberately replicated against
the new frozen head. It is not presented as a new held-out seed. The adversary
has the same ten-candidate query budget per round and uses validation ASR.
Every round trains unmodified and poisoned local endpoints from the actual
current base and modifies only its three exports. Its chosen factors are
`{alphas}`. A factor of zero is an actually unmodified export for that round,
not a poisoned update. The trajectory contains {manipulated} nonzero manipulated
updates and {summary['adaptive_quarantined_updates']} total quarantines.

Peak full-trigger validation ASR is **{100*peak:.4f}%**, final ASR
**{100*summary['adaptive_final_validation_asr']:.4f}%**. The matched six-round
clean arm has zero full-trigger ASR. All **270 local trainings, 60 candidate
queries and 12 aggregates** are repeated exactly. This is a bounded offline
post-training manipulation experiment, not a TPM or declared-training-contract
bypass. The chosen factors depend on the head and change its future bases;
comparison with the older pilot is not a paired fixed-update superiority test.

## Conditional mathematics and remaining limit

For window H, an isolated old peak leaves the window after H observations.
If supported positive excess then remains constant, it becomes non-receding
and two current observations confirm it. The blanket promise of a fixed
confirmation bound for every positive sequence is false: alternating excess
0.4/0.01 above a limit can alternate retained/receding observations forever.
The six prototype tests include this counterexample, exact retry binding,
failed gates, unsupported resets, sharp-retreat release and window identity.
The real adaptive experiment demonstrates a related evasion with trained
model updates. A signed submission establishes origin, not semantic innocence.

Changing a peak window or a confirmation counter alone is insufficient for
the intended automatic-exclusion claim. Stronger containment should be evaluated
as a separate aggregation/influence contract, with detector alerts kept distinct
from proof of malice; see [the next-step design](NEXT_STEP_DESIGN.md).

## Integrity and scope

The prototype and its six tests are research files under this output directory;
the maintained 117-file live package remains unchanged at
`{implementation_sha256()}`. Its previous 652-test validation and TPM evidence
remain versioned, not relabeled as tests of this prototype. No new Docker/TPM
campaign, ToN-IoT work, commit, push or thesis edit is performed here. All new
reports are in English. Raw evidence is retained in the two versioned artifact
directories, with a source/controller archive and local analyst-signed closure.
The closure is an integrity record, not independent witness time or certification.
'''
md(out/'REPORT.md',report)
design='''# Next structural experiment — proposal, not an implemented guarantee

The automatic gate should not equate a residual pattern with malicious intent.
Keep mandatory trust rejection and unsupported-context failure. Keep semantic
alerts and retrospective group selection as auditable hypotheses.

A separately specified containment experiment can clip each admitted local
delta to clean-calibrated per-tensor bounds before aggregation, retaining both
the original signed update and the exact derived clipped object. Record clipping
factors, effective masses and the actual aggregate, and independently reconstruct
them. Fit bounds only on reserved clean references, including unmodified local
responses to generic perturbed shared states. Freeze all bounds and the utility
error budget before evaluation; do not fit to these newly observed attack paths.

For a single tensor with convex weights a_i and all clipped deltas of norm at
most C, the aggregate delta has norm at most C. Removing client k and
renormalizing the others changes it by
||a_k(u_k - mu_-k)|| <= 2 a_k C, provided a_k<1. This is a deterministic influence
bound, not proof of benign behavior or a bound on ASR near a decision boundary.
Across later rounds, local updates must be retrained from the modified base;
adding per-round norm bounds does not prove causal recovery or absence of a
backdoor. Quorum, utility loss, non-IID behavior, component triggers, adaptive
search and matched attack-effective controls must all be measured.

This is a concrete next experimental specification. It is not yet code or a
validated mitigation, and clipping already used by a literature baseline must
not be presented as an original defense contribution. The thesis contribution
can instead concern authenticated derivation, exact influence accounting and
reproducible diagnosis under explicit assumptions.
'''
md(out/'NEXT_STEP_DESIGN.md',design)
md(repo/'docs/ROLLING_ENVELOPE_VALIDATION.md',report.replace('](NEXT_STEP_DESIGN.md)','](../results/revision-rolling-envelope-validation-v1/NEXT_STEP_DESIGN.md)'))
for name in ('STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md'):
    with (repo/'docs'/name).open('a') as stream:stream.write('\n\n## Rolling-peak follow-up — 3 November 2026\n\nThe frozen two-round candidate passed old development guardrails but failed the real adaptive replication. It is not promoted; the maintained live package is unchanged. See [ROLLING_ENVELOPE_VALIDATION.md](ROLLING_ENVELOPE_VALIDATION.md).\n')
with zipfile.ZipFile(out/'prototype-and-controllers.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.glob('*.py')):z.write(p,p.name)
    for p in sorted((repo/'src/fl_forensics').glob('*.py')):z.write(p,'maintained-source/fl_forensics/'+p.name)
for root in (lab,ad):
    files={p.relative_to(root).as_posix():sha256_file(p) for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='public-closure.json' and not any('private' in x.lower() for x in p.relative_to(root).parts)}
    save(root/'public-closure.json',{'profile':'rolling-research-artifact-closure-v1','files':files})
    save(out/(root.name+'-closure.json'),{'root':str(root),'closure_sha256':sha256_file(root/'public-closure.json')})
prior=read(out.parent/'adaptive-live-policy-20261103/before.json')
assert sha256_file(repo/'.git/index')==prior['git_index_sha256']
thesis=read(out.parent/'formal-closure-20261103/before-review.json')
assert all(sha256_file(Path(thesis['thesis_root'])/n)==h for n,h in thesis['thesis_sources'].items())
signer=SoftwareECDSASigner.generate();write_once(repo/'artifacts/revision-rolling-authority-v1/analyst.private.pem',signer.private_pem())
write_once(out/'analyst.public.pem',signer.public_pem())
core={'profile':'rolling-research-completion-v1','parent_completion_sha256':'1fb6891228c0064eb8ebd6cce678b83b7dc3555d986c76cebd931fc3be54e9aa',
      'summary':summary,'artifacts':{p.relative_to(out).as_posix():sha256_file(p) for p in sorted(out.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ('completion.json','completion.sha256')},
      'maintained_documents':{n:sha256_file(repo/'docs'/n) for n in ('ROLLING_ENVELOPE_VALIDATION.md','STATUS.md','SUPERVISOR_REQUIREMENTS_AUDIT.md')},
      'authority_role':'Local software analyst; integrity only, no independent time or certification'}
d=sha256_bytes(derived_json_bytes(core));sig=signer.sign_digest(d)
save(out/'completion.json',{'core':core,'core_digest':d,'signature':{'key_id':signer.key_id,'value_b64':sig}})
assert verify_digest_signature(load_public_key(signer.public_pem()),d,sig)
assert all(sha256_file(out/n)==h for n,h in core['artifacts'].items())
write_once(out/'completion.sha256',(sha256_file(out/'completion.json')+'\n').encode())
for p in out.iterdir():
    if p.is_file() and p.suffix in ('.md','.json','.zip','.xml','.log','.pem','.sha256'):shutil.copyfile(p,dest/p.name)
shutil.copyfile(out/'REPORT.md',dest/'README.md')
print('ROLLING RESEARCH SEALED',sha256_file(out/'completion.json'),json.dumps(summary),flush=True)
