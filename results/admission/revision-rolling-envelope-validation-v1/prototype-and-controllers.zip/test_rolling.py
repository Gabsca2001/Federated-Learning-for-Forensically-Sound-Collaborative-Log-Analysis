import pytest
from test_client_envelope_policy import policy,step
from rolling_policy import RollingEnvelopePolicy

def new(w=2):
    old=policy();return RollingEnvelopePolicy(old.cal,old.envelope,minimum_contributors=2,peak_window_rounds=w)

def test_plateau_recovers_after_initial_peak_expires():
    p=new();assert not step(p,1,2.4)['quarantine_current_round']
    assert not step(p,2,2.1)['quarantine_current_round']
    assert not step(p,3,2.1)['quarantine_current_round']
    assert step(p,4,2.1)['quarantine_current_round']==['a']

def test_sharp_retreat_releases_immediately():
    p=new();step(p,1,10);step(p,2,10)
    assert not step(p,3,2.1)['quarantine_current_round']

def test_unsupported_and_failed_gates_reset_confirmation():
    p=new();step(p,1,3);step(p,2,3)
    assert not step(p,3,3,support=False)['quarantine_current_round']
    r=step(p,4,3,gates={'a':False,'b':True,'c':True})
    assert r['proposed_effective_masses']['a']=='0'

def test_conflicting_retries_are_rejected():
    p=new();h=p.head;r=step(p,1,3)
    assert step(p,1,3,previous=h)==r
    with pytest.raises(ValueError):step(p,1,3,previous=h,source='b'*64)

def test_window_changes_the_bound_decision_digest():
    assert step(new(2),1,3)['decision_digest']!=step(new(3),1,3)['decision_digest']

def test_periodic_spikes_remain_a_counterexample_to_universal_confirmation():
    p=new()
    for t in range(1,16):assert not step(p,t,2.4 if t%2 else 2.01)['quarantine_current_round']
