"""Develop a separately versioned rolling-peak research profile."""
from pathlib import Path
import hashlib,json,shutil,sys
repo=Path.cwd();out=Path(__file__).parent
lab=repo/'artifacts/revision-rolling-envelope-v1';lab.mkdir(exist_ok=True)
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    data=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
    if p.exists():assert p.read_bytes()==data,p
    else:p.write_bytes(data)
from fl_forensics.round_derivation import implementation_sha256
assert implementation_sha256()=='9756ea7efd479992a9aecfc45953b476131e1ad9edfa0bfae32032db50839ff7'
source=(repo/'src/fl_forensics/client_envelope_policy.py').read_text()
# Prototype only: the maintained package and live profile remain unchanged.
source=source.replace('from .','from fl_forensics.')
source=source.replace('ClientEnvelopePolicy','RollingEnvelopePolicy').replace('client-envelope-retreat-policy-v1','rolling-client-envelope-retreat-policy-v1')
source=source.replace('minimum_contributors=8):','minimum_contributors=8, peak_window_rounds=2):')
source=source.replace('        self._prior =', '        self._prior =') # Source is formatted in the authoritative repository.
needle='        self._prior=CurrentEvidencePolicy'
if needle in source:
    source=source.replace(needle,'        if type(peak_window_rounds) is not int or peak_window_rounds not in (2,3,4): raise ValueError("invalid peak window")\n        self.window=peak_window_rounds; self._history=[]\n'+needle)
else:
    needle='        self._prior = CurrentEvidencePolicy'
    assert needle in source
    source=source.replace(needle,'        if type(peak_window_rounds) is not int or peak_window_rounds not in (2,3,4): raise ValueError("invalid peak window")\n        self.window=peak_window_rounds; self._history=[]\n'+needle)
old='peak = np.where(high, np.maximum(self._peak, excess), 0.0)'
if old not in source:old='peak=np.where(high,np.maximum(self._peak,excess),0.)'
assert old in source
source=source.replace(old,'history = [row.copy() for row in self._history] + [np.maximum(excess,0.)]\n            history = history[-self.window:]\n            for row in history: row[~high] = 0.\n            peak = np.max(history,axis=0)')
needle='        baseline = set('
if needle not in source:needle='        baseline=set('
assert needle in source
source=source.replace(needle,'        if not basis["supported"]: history=[]\n'+needle)
needle='        self._peak = peak'
if needle not in source:needle='        self._peak=peak'
assert needle in source
source=source.replace(needle,'        self._history=history\n'+needle)
needle='"retained_peak_fraction": 0.5,'
if needle not in source:needle="'retained_peak_fraction':.5,"
assert needle in source
source=source.replace(needle,needle+' "peak_window_rounds":self.window,')
path=out/'rolling_policy.py'
if path.exists():assert path.read_text()==source
else:path.write_text(source)
sys.path.insert(0,str(out))
from rolling_policy import RollingEnvelopePolicy
from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
save(lab/'development-protocol-before-scoring.json',{'profile':'rolling-peak-development-v1',
    'windows':[2,3,4],'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'selection':'Zero never-attacker/currently-clean scheduled-attacker proposals and quorum failures on the 48 old development cases. Among eligible windows maximize shadow TP, ties smallest window; otherwise reject.',
    'no_new_evaluation_training_generated':True,'calibration':'Unchanged frozen clean-only references; no attack identities enter detector input.',
    'scope':'Peak memory expires, but temporal variability can still prevent confirmation. This is not a universal bounded-confirmation guarantee.'})
names=['retreat','rolling-2','rolling-3','rolling-4'];rows=[]
for source_name in ('revision-sequential-round-policy-v1','revision-current-evidence-policy-v1'):
    root=repo/'artifacts'/source_name
    for task in json.loads((root/'reserved-execution-before-training.json').read_bytes())['tasks']:
        cohort=task['cohort'];p=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
        cal=json.loads((p/f'{cohort}.json').read_bytes());env=json.loads((p/f'{cohort}-envelope.json').read_bytes())
        policies={'retreat':ClientEnvelopePolicy(cal,env)}
        policies.update({f'rolling-{w}':RollingEnvelopePolicy(cal,env,peak_window_rounds=w) for w in (2,3,4)})
        counts={n:dict(tp=0,never=0,clean_scheduled=0,quorum=0) for n in names}
        for number in range(1,16):
            response=json.loads((root/'private-episodes'/task['stream']/'rounds'/f'round-{number:03d}'/'worker-response.json').read_bytes())['scored']
            support=all(response['state_distances'][v][0]<=min(cal['state_support_limits'][v],env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in ('conditioned','state-disabled'))
            intended=set(task['attackers']) if task['mode']=='distributed' else set();active=intended if number in task['attack_rounds'] else set()
            for name,policy in policies.items():
                r=policy.step(number,{v:response['risk'][v][0] for v in ('conditioned','state-disabled')},context_supported=support,
                    mandatory_gate=dict.fromkeys(cal['clients'],True),masses=dict.fromkeys(cal['clients'],1),expected_previous_digest=policy.head,
                    source_observation_sha256=hashlib.sha256(f'{source_name}:{task["stream"]}:{number}'.encode()).hexdigest())
                chosen=set(r['quarantine_current_round']);c=counts[name]
                c['tp']+=len(chosen&active);c['never']+=len(chosen-intended);c['clean_scheduled']+=len((chosen&intended)-active);c['quorum']+=int(not r['proposal_quorum_satisfied'])
        rows.append({'source':source_name,'task':task,'methods':counts})
totals={n:{k:sum(r['methods'][n][k] for r in rows) for k in ('tp','never','clean_scheduled','quorum')} for n in names}
for n in names:totals[n]['shadow_tp']=sum(r['methods'][n]['tp'] for r in rows if r['task']['branch']=='shadow-FedAvg')
eligible=[n for n in names[1:] if not any(totals[n][k] for k in ('never','clean_scheduled','quorum'))]
selected=max(eligible,key=lambda n:(totals[n]['shadow_tp'],-names.index(n))) if eligible else None
result={'totals':totals,'selected':selected,'cases':rows}
save(lab/'development-results.json',result);save(out/'development-results.json',result)
print(json.dumps({'totals':totals,'selected':selected}),flush=True)
