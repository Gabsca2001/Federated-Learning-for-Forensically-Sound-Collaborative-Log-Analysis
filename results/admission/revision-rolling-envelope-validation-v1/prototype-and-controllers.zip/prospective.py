"""Frozen paired active trajectories; no test split and no live-source changes."""
from pathlib import Path
import sys,json,hashlib,copy
import numpy as np
out=Path(__file__).parent
sys.path[:0]=[str(out),str(out.parent/'state-conditioned-detector-20261103'),str(out.parent/'geometry-detector-20261103')]
from rolling_policy import RollingEnvelopePolicy
from policy_data import Generator,current_observation,aggregate_selected
from revision_dba_experiment import save,outcomes,predict
from fl_forensics.client_envelope_policy import ClientEnvelopePolicy
from fl_forensics.state_conditioned_audit import load_model,residual_scores
from fl_forensics.federated_model import arrays_from_export
from fl_forensics.canonical import sha256_file,sha256_bytes
from fl_forensics.preprocessing import derived_json_bytes
from fl_forensics.distributed_backdoor import DistributedBackdoorPlan

repo=Path.cwd();lab=repo/'artifacts/revision-rolling-envelope-v1'
development=json.loads((lab/'development-results.json').read_bytes());assert development['selected']=='rolling-2'
tasks=[dict(cohort=cohort,seed=seed,attackers=attackers,mode=mode,head=head) for cohort,seed,attackers in
       [('iid',561593,['client02','client09','client14']),('non-iid',571593,['client03','client08','client12'])]
       for mode in ('clean','distributed') for head in ('retreat','rolling-2')]
protocol={'profile':'paired-rolling-peak-prospective-v1','tasks':tasks,'horizon':15,'attack_rounds':list(range(1,7)),
    'purpose':'Six attack rounds plus nine clean continuations test delayed false exclusions on contaminated bases. Eight paired active trajectories; one fresh seed per cohort, no independent dataset claim.',
    'source_sha256':sha256_file(out/'rolling_policy.py'),'controller_sha256':sha256_file(Path(__file__)),
    'development_sha256':sha256_file(lab/'development-results.json'),
    'promotion':'No promotion if any currently clean update is excluded, a clean trajectory is unsupported, quorum is lost, or the separately declared adaptive search demonstrates evasion. Positive finite results still do not establish universal semantic detection.',
    'evaluation':'Every fixed validation endpoint: clean utility, full/component triggers, current attack interceptions and clean exclusions. No test access or threshold tuning.',
    'sampled_training_replay':'Repeat all 15 local trainings at rounds 1 and 15 of each completed trajectory; recompute every policy result and aggregate from retained models.',
    'TPM':False,'maintained_live_source_changed':False}
save(lab/'prospective-protocol-before-training.json',protocol)
cfg=json.loads((repo/'artifacts/revision-dba-three-seed-v1/distributed-s341593/protocol-before-training.json').read_bytes())
allresults=[];counts=dict(generation_local_trainings=0,repeated_local_trainings=0,rounds_verified=0)
for task in tasks:
    name=f"{task['cohort']}-{task['mode']}-{task['head']}";case=lab/'prospective'/name
    assert not case.exists(), 'One-shot reserved case; preserve partial outputs'
    save(case/'protocol.json',task)
    part='m3-data24-parquet-iid-local-test-v1' if task['cohort']=='iid' else 'm3-data24-parquet-non-iid'
    gen=Generator(repo/'artifacts'/part,cfg);masses={c:len(gen.rows[c]) for c in gen.clients}
    rows=json.loads(Path(cfg['validation_path']).read_bytes())['rows']['validation']
    ref,_=predict(gen.initial,rows,gen.deps);correct=[p==r['label'] for p,r in zip(ref,rows,strict=True)]
    calroot=repo/'artifacts/revision-geometry-detector-v1/policy-calibration'
    cal=json.loads((calroot/f'{task["cohort"]}.json').read_bytes());env=json.loads((calroot/f'{task["cohort"]}-envelope.json').read_bytes())
    modelroot=repo/'artifacts/revision-state-conditioned-heldout-v1/models'/task['cohort']
    models={v:load_model(modelroot/f'{v}.npz') for v in ('conditioned','state-disabled')}
    constructor=ClientEnvelopePolicy if task['head']=='retreat' else RollingEnvelopePolicy
    policy=constructor(cal,env);verifier=constructor(cal,env)
    plan=DistributedBackdoorPlan.model_validate({**cfg['attack_plan'],'seed':task['seed'],
        'client_components':dict(zip(task['attackers'],[[13],[17],[24]],strict=True)),'attack_rounds':list(range(1,7))})
    base=gen.initial;results=[]
    for number in range(1,16):
        target=case/'rounds'/f'round-{number:03d}';save(target/'base-model.json',base)
        _,deltas,exports,training=gen.execute(base,task['seed'],number,plan if task['mode']=='distributed' else None)
        counts['generation_local_trainings']+=15
        if number in (1,15):
            _,again,repeat,_=gen.execute(base,task['seed'],number,plan if task['mode']=='distributed' else None)
            assert repeat==exports;counts['repeated_local_trainings']+=15
        for c,e in zip(gen.clients,exports,strict=True):save(target/'updates'/f'{c}.json',e)
        observation=current_observation(base,deltas,gen.clients,{})
        observation.pop('source',None);observation['cohort_id']=sha256_file(gen.root/'manifest.json')
        scored={v:residual_scores(observation,m) for v,m in models.items()}
        supported=all(scored[v]['state_support_distance'][0]<=min(cal['state_support_limits'][v],env['state_support_limits'][v])*(1+1e-12)+1e-12 for v in models)
        risk={v:scored[v]['risk'][0].tolist() for v in models}
        source=hashlib.sha256(b''.join(derived_json_bytes(e) for e in [base,*exports])).hexdigest()
        args=dict(context_supported=supported,mandatory_gate=dict.fromkeys(gen.clients,True),masses=masses,source_observation_sha256=source)
        decision=policy.step(number,risk,expected_previous_digest=policy.head,**args)
        assert verifier.step(number,risk,expected_previous_digest=verifier.head,**args)==decision
        save(target/'decision.json',decision);save(target/'observed-risks.json',risk)
        model=aggregate_selected(gen,base,exports,decision['quarantine_current_round']) if supported else None
        if model is None:
            save(target/'failure.json',{'supported':supported,'reason':'unsupported context or quorum loss'});break
        duplicate=aggregate_selected(gen,base,exports,decision['quarantine_current_round']);assert duplicate==model
        counts['rounds_verified']+=1
        active=set(task['attackers']) if task['mode']=='distributed' and number<=6 else set()
        chosen=set(decision['quarantine_current_round'])
        row={'round':number,'quarantined':sorted(chosen),'tp':len(chosen&active),'false_current':len(chosen-active),
             'poisoned_updates':len(active),'validation':outcomes(model,rows,plan,correct,gen.deps)}
        save(target/'global-model.json',model);save(target/'round.json',row);results.append(row);base=model
        print(json.dumps({'case':name,'round':number,'tp':row['tp'],'false_current':row['false_current']}),flush=True)
    gen.close(case)
    allresults.append({'task':task,'rounds':results,'complete':len(results)==15,
        'intercepted':sum(r['tp'] for r in results),'false_current':sum(r['false_current'] for r in results),
        'peak_asr':max((r['validation']['complete_trigger']['asr'] for r in results),default=None),
        'manifest_sha256':sha256_file(case/'manifest.json')})
save(lab/'prospective-results.json',{'cases':allresults,'counts':counts})
(out/'prospective-results.json').write_bytes((lab/'prospective-results.json').read_bytes())
print('PAIRED PROSPECTIVE CASES COMPLETED',json.dumps(counts),flush=True)
