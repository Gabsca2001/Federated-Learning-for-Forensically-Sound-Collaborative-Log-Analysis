# Repository documentation

- Write and maintain repository documentation in English, including headings,
  explanatory comments in examples, placeholder text, and new status reports.
- Preserve API names, command-line options, schema fields, and scientific
  qualifications when translating documentation.
- Do not rewrite immutable historical evidence, signed artifacts, preserved
  releases, or original correspondence to change their language. Translate the
  maintained explanation separately and identify quotations as source material.
